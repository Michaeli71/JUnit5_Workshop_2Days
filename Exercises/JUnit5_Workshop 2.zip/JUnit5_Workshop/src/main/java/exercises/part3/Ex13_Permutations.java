package exercises.part3;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex13_Permutations 
{
    // Permutatiionen berechnen
    // ------------------------
    // A => p(A) => A
    // AB =>  A + p(B) + B + p(A) => AB + BA
    // ABC => A + p(BC) + B + p(AC) + C + p(AB)     
    public static Set<String> calcPermutations(final String input)
    {
        if (input.isEmpty())
            return Collections.singleton(input);
        if (input.length() == 1)
            return Collections.singleton(input);

        final Set<String> combinations = new HashSet<>();
        for (int i = 0; i < input.length(); i++)
        {
            // extract next first char
            final String newFirst = input.substring(i, i + 1);
            // create string of the remaining 
            final String newInput = input.substring(0, i) + input.substring(i + 1);

            // calc recursively
            final Set<String> permutations = calcPermutations(newInput);

            // add first char to solution
            for (final String perm : permutations)
            {
                combinations.add(newFirst + perm);
            }
        }
        return combinations;
    }
}
