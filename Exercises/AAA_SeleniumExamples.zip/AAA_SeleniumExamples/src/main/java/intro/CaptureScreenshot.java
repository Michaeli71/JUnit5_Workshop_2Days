package intro;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class CaptureScreenshot
{
    public static void main(String[] args) throws IOException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        final WebDriver driver = new FirefoxDriver();

        try
        {
            driver.get("http://www.heise.de");

            // capture the screenshot
            final File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            
            // copy to destination
            Path targetPath = Paths.get("./ScreenShot.jpg");
            Files.move(scrFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        }
        finally
        {
            driver.quit();
        }
    }
}