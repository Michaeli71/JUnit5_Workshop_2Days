package wiremock_intro;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static io.restassured.RestAssured.given;

import org.junit.Rule;
import org.junit.Test;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.github.tomakehurst.wiremock.stubbing.Scenario;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 *         Copyright 2020 by Michael Inden
 */
public class WireMockStatefulTest 
{
	@Rule
	public WireMockRule wireMockRule = new WireMockRule(8089);
	// No-args constructor defaults to port 8080 (we use this for DOCKER)

@Test
public void testStatefulMock() 
{
	setupStatefulStub();

	given().
	when().
		get("http://localhost:8089/shoppingcart").
	then().
		assertThat().
		statusCode(200).
		and().
		assertThat().body("list", org.hamcrest.Matchers.equalTo("Empty"));
		
	given().
	when().
		post("http://localhost:8089/shoppingcart").
	then().
		assertThat().
		statusCode(201);
		
	given().
	when().
		get("http://localhost:8089/shoppingcart").
	then().
		assertThat().
		statusCode(200).
		and().
		assertThat().body("list.item", org.hamcrest.Matchers.equalTo("Item 1"));
		
		// -----------------------
		
		given().
		when().
			post("http://localhost:8089/shoppingcart").
		then().
			assertThat().
			statusCode(201);
			
		given().
		when().
			get("http://localhost:8089/shoppingcart").
		then().
			assertThat().
			statusCode(200).
			and().
			assertThat().body(org.hamcrest.Matchers.hasXPath("count(//item)",  org.hamcrest.Matchers.equalTo("2"))).
			assertThat().body("list.item[0]", org.hamcrest.Matchers.equalTo("Item 1")).
			assertThat().body("list.item[1]", org.hamcrest.Matchers.equalTo("Item 2"));
	}

	
	public void setupStatefulStub() {
		
		stubFor(get(urlEqualTo("/shoppingcart"))
				.inScenario("shopping")
				.whenScenarioStateIs(Scenario.STARTED)
				.willReturn(aResponse()
	                .withStatus(200)
	                .withHeader("Content-Type", "application/xml")
	                .withBody("<list>Empty</list>")));
			
		stubFor(post(urlEqualTo("/shoppingcart"))
				.inScenario("shopping")
				.whenScenarioStateIs(Scenario.STARTED)
				.willSetStateTo("itemAdded-1")
				.willReturn(aResponse()
					.withHeader("Content-Type", "application/xml")
	                .withStatus(201)));
			
		stubFor(get(urlEqualTo("/shoppingcart"))
				.inScenario("shopping")
				.whenScenarioStateIs("itemAdded-1")
				.willReturn(aResponse()
	                .withStatus(200)
	                .withHeader("Content-Type", "application/xml")
	                .withBody("<list><item>Item 1</item></list>")));	
		
		// ---------------------------------------
		
		stubFor(post(urlEqualTo("/shoppingcart"))
				.inScenario("shopping")
				.whenScenarioStateIs("itemAdded-1")
				.willSetStateTo("itemAdded-2")
				.willReturn(aResponse()
					.withHeader("Content-Type", "application/xml")
	                .withStatus(201)));
		
		stubFor(get(urlEqualTo("/shoppingcart"))
				.inScenario("shopping")
				.whenScenarioStateIs("itemAdded-2")
				.willReturn(aResponse()
	                .withStatus(200)
	                .withHeader("Content-Type", "application/xml")
	                .withBody("<list><item>Item 1</item><item>Item 2</item></list>")));	
	}
}
