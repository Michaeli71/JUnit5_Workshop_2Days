docker pull rodolpheche/wiremock
docker run -it --rm -p 8080:8080 rodolpheche/wiremock
