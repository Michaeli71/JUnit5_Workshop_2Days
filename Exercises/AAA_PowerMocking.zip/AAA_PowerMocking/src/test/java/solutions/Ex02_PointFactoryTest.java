package solutions;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.awt.Point;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex02_PointFactory;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(Ex02_PointFactory.class)
public class Ex02_PointFactoryTest
{
    @Test
    public void testPointInstantiation() throws Exception
    {
        Point mockPoint = mock(Point.class);
        Mockito.when(mockPoint.getLocation()).thenReturn(new Point(72, 71));
        PowerMockito.whenNew(Point.class).withAnyArguments().thenReturn(mockPoint);

        Ex02_PointFactory factory = new Ex02_PointFactory();
        Point actualMockPoint = factory.create();

        assertAll(() -> assertEquals(72, actualMockPoint.getLocation().getX()),
                  () -> assertEquals(71, actualMockPoint.getLocation().getY()));
    }
}
