package exercises;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex03_FigureFactory.FigureTypes;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class Ex03_FigureFactoryTest
{
    // TODO
    @Test
    public void test_factory_method()
    {
        // ARRANGE
        // TODO
        
        // ACT
        String result = Ex03_FigureFactory.getFigure(FigureTypes.CIRCLE);
        String result2 = Ex03_FigureFactory.getFigure(FigureTypes.HEXAGON);
        
        // ASSERT
        assertAll(() -> assertEquals("CIRCLE", result),
                  () -> assertNull(result2));
    }
    
    // TODO
    @Test
    public void test_factory_method_for_unimplemented_case()
    {
        // ARRANGE
        // TODO
        
        // ACT
        String result = Ex03_FigureFactory.getFigure(FigureTypes.HEXAGON);
        
        // ASSERT
        assertEquals("HEXAGON", result);
    }
}