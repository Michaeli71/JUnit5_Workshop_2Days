package exercises.part5_6;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Arabic2RomanConverter 
{
	public String convert(int i) 
	{
		return "" + i;
	}
}
