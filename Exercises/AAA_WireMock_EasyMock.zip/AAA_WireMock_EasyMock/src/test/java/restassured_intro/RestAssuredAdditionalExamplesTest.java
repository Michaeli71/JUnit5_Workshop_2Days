package restassured_intro;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.junit.Test;

import io.restassured.http.ContentType;
import net.minidev.json.JSONObject;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RestAssuredAdditionalExamplesTest 
{
	@Test
	public void test_with_logging() {

		given().get("https://reqres.in/api/users?page=2").
		then().statusCode(200).
		       log().all();
	}
	
	@Test
	public void test_post() {
	
	    JSONObject request = new JSONObject();
	    request.put("name", "Michael");
	    request.put("job", "Trainer");
	
	    given().body(request.toJSONString()).
	    when().post("https://reqres.in/api/users").
	    then().statusCode(201);
	}
	
	@Test
	public void test_delete() 
	{
	    given().
	    when().delete("https://reqres.in/api/users/5").
	    then().statusCode(204);
	}
	
	@Test
	public void checkContentTypeAndLog() 
	{	        
	    given().
	        pathParam("country","ch").
	        pathParam("zipcode","8047").
	    when().
	        get("http://api.zippopotam.us/{country}/{zipcode}").
	    then().
	        assertThat().statusCode(200).
	        body("places.'place name'[0]", equalTo("Zürich")).
	     and().
	        contentType(ContentType.JSON).
	        log().all();
	}
}