package utils;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class CollectionUtils
{
    public static <T> List<T> listRemoveDuplicates(List<T> inputs)
    {
        final Set<T> noDuplicates = new LinkedHashSet<>(inputs);

        return new ArrayList<>(noDuplicates);
    }
}
