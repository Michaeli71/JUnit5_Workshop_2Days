package solutions.part5_6;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import exercises.part5_6.Ex04_ChatEngine;
import exercises.part5_6.MessageSender;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
//@ExtendWith(MockitoExtension.class)
class Ex04_ChatEngineTest
{
    //@Mock
    //private MessageSender messageSender;

    @Test
    public void shouldUseMessageSenderToSendMessage()
    {
        final String msg = "SECRET";
        final String expectedAnswer = "SERVICE";

        // ARRANGE
        // spy
        MessageSender messageSender = Mockito.mock(MessageSender.class);
        Mockito.when(messageSender.send(msg)).thenReturn(expectedAnswer);

        final Ex04_ChatEngine chatEngine = new Ex04_ChatEngine(messageSender);

        // ACT
        final String response = chatEngine.say(msg);
        /*
        final String response2 = chatEngine.say("JUNIT 5 is cool");
        System.out.println("response2: " + response2);
        */

        // ASSERT
        Mockito.verify(messageSender).send(msg);
        assertThat(response).isEqualTo(expectedAnswer);
    }
}