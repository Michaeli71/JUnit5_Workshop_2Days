package exercises.part5_6;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_PizzaService
{
    private final SmsNotificationService notificationService;

    public Ex02_PizzaService()
    {
        notificationService = new SmsNotificationService();
    }

    public void orderPizza(final String name)
    {
        notificationService.notify("Pizza " + name + " wird in Kürze geliefert.");
    }
}
