package solutions;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex04_ServiceWithDependency;
import exercises.Ex04_SystemStateService;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class Ex04_ServiceWithDependencyTest
{
    @Test
    @PrepareForTest(Ex04_SystemStateService.class)
    public void testModifiyResultOfFinalMethod()
    {
        Ex04_SystemStateService stateService = PowerMockito.mock(Ex04_SystemStateService.class);
        PowerMockito.when(stateService.isAlive()).thenReturn(true);
        
        Ex04_ServiceWithDependency service = new Ex04_ServiceWithDependency();        
        boolean systemIsAlive = service.callFinalMethod(stateService);        
        
        assertTrue(systemIsAlive);
    }
}