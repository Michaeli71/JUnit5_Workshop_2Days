package x_slides.part3_junit5_advanced;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import utils.PrimeNumberChecker;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@RunWith(Parameterized.class)
public class A_PrimeNumberCheckerJUnit4Test
{
    private int inputNumber;

    private boolean expectedResult;

    // Each parameter should be placed as an argument here
    public A_PrimeNumberCheckerJUnit4Test(int inputNumber, boolean expectedResult)
    {
        this.inputNumber = inputNumber;
        this.expectedResult = expectedResult;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> primeNumbers()
    {
        return Arrays.asList(new Object[][] { { 2, true }, { 3, true }, { 6, false }, { 11, true }, { 14, false } });
    }

    // This test will run n times since we have a lot of parameters defined
    @Test
    public void testPrimeNumberChecker()
    {
        System.out.println("Parameterized Number is : " + inputNumber);
        assertEquals(expectedResult, PrimeNumberChecker.isPrime(inputNumber));
    }
}