package solutions;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

import exercises.Ex01_SystemProperties;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex01_SystemPropertiesWithExtractAndOverrideTest
{
    @Test
    public void access_system_property()
    {
        // ARRANGE
        final Ex01_SystemProperties sut = new Ex01_SystemProperties()
        {
            @Override
            public String getSystemProperty(String propertyName)
            {
                if (propertyName.equals("ABC"))
                    return "POWER-MOCKED";
                return null;
            }
        };

        // ACT
        String result1 = sut.getSystemProperty("ABC");
        String result2 = sut.getSystemProperty("XYZ");

        // ASSERT
        assertAll(() -> assertEquals("POWER-MOCKED", result1),
                  () -> assertNull(result2));
    }
}
