package solutions.part5_6;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import exercises.part5_6.SmsNotificationService;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_PizzaServiceTest
{
    @Test
    public void orderPizza_should_send_sms()
    {
        // Arrange
        final StubNotificationService stub = new StubNotificationService();
       // SmsNotificationService mockedService = Mockito.mock(SmsNotificationService.class);
        
        final Ex02_PizzaService service = new Ex02_PizzaService()
        {
            @Override
            protected SmsNotificationService getNotificationService()
            {
                return stub;
            }
        };

        // Act
        service.orderPizza("Diavolo");
        service.orderPizza("Surprise");

        // Assert  
        assertTrue(stub.getMessages().contains("Pizza Diavolo wird in Kürze geliefert."));
        assertThat(stub.getMessages()).contains("Pizza Surprise wird in Kürze geliefert.");
        assertThat(stub.getMessages()).containsExactlyInAnyOrder("Pizza Surprise wird in Kürze geliefert.", 
                                                                 "Pizza Diavolo wird in Kürze geliefert.");
        
        // Alternative: Aber Problem ... man kommt nicht so schön an die Daten
//        Mockito.verify(mockedService).notify("Pizza Diavolo wird in Kürze geliefert.");
//        Mockito.verify(mockedService).notify("Pizza Surprise wird in Kürze geliefert.");        
    }
}
