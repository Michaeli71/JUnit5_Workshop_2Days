package exercises;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.suppress;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ Ex09_MethodSupressVerify.class })
public class Ex09_MethodSupressVerifyTest
{
    @Test
    public void testSuppressSuperMethodCall() throws Exception
    {
    	PowerMockito.mockStatic(Ex09_MethodSupressVerify.class);
    	
        suppress(method(Ex09_MethodSupressVerify.class, "calc"));
        //suppress(method(Ex09_MethodSupressVerify.class, "staticMethod"));
                
        int result1 = new Ex09_MethodSupressVerify().calc("ABC");
        int result2 = Ex09_MethodSupressVerify.staticMethod("XYZ");
        
        assertAll(() -> assertEquals(0, result1),
        		  () -> assertEquals(0, result2));
                
        PowerMockito.verifyStatic(Ex09_MethodSupressVerify.class);
        Ex09_MethodSupressVerify.staticMethod("XYZ");
    }
}