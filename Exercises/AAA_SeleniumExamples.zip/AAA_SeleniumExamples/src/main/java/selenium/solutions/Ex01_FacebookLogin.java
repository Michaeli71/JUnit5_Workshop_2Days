package selenium.solutions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex01_FacebookLogin
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        WebDriver driver = new FirefoxDriver();

        try
        {
            driver.get("http://www.facebook.com");
            WebElement emailInput = driver.findElement(By.id("email"));
            System.out.println(emailInput.getTagName());

            WebElement passwordInput = driver.findElement(By.cssSelector("#pass"));
            System.out.println(passwordInput.getTagName());

            WebElement anmeldenButton = driver.findElement(By.name("login"));
            System.out.println(anmeldenButton.getTagName());

            emailInput.sendKeys("Peter");
            passwordInput.sendKeys("Lustig");
            Thread.sleep(2_000);

            passwordInput.clear();
            passwordInput.sendKeys("NICHT_Lustig");

            Thread.sleep(2_000);

            anmeldenButton.submit();

            Thread.sleep(5_000);
        }
        finally
        {
            driver.close();
        }
    }
}