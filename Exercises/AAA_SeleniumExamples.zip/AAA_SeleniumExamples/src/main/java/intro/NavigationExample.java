package intro;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class NavigationExample
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        final WebDriver driver = new FirefoxDriver();

        try
        {
            driver.get("http://www.facebook.com");

            driver.navigate().to("http://www.amazon.de");
            driver.navigate().back();

            openNewTab(driver);
            driver.get("https://t3n.de/news/iphone-12-pro-review-roundup-1329698/");

            openNewTab(driver);
            driver.get("https://www.apple.com/chde/iphone-12-pro/");

            Thread.sleep(2_000);
        }
        finally
        {
            driver.quit();
        }
    }

    public static void openNewTab(final WebDriver driver) throws InterruptedException
    {
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.open()");

        Thread.sleep(200);

        final List<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(tabs.size() - 1));
    }
}