package selenium.exercises;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex02_SimpleGoogleSeach
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

        WebDriver driver = new FirefoxDriver();

        try
        {
            int count = searchFor(driver, "Selenium");
            System.out.println("Result count:" + count);
    
            count = searchForV2(driver, "iPhone 12 Pro");
            System.out.println("Result count:" + count);
        }
        finally
        {
            driver.quit();
        }
    }

    public static int searchFor(WebDriver driver, String searchQuery) 
    {
        driver.get("https://www.google.com");

        // TODO
        return 0;
    }

    public static int searchForV2(WebDriver driver, String searchQuery)  
    {
        driver.get("http://www.google.com");
        // TODO
        return 0;
    }
}
