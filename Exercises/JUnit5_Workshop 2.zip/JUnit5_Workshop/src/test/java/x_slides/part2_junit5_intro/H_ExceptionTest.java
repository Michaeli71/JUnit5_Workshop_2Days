package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class H_ExceptionTest
{
    @Test
    void cannotSetValueToNull()
    {
        assertThrows(NullPointerException.class, () -> new BigDecimal((String) null));
    }

    @Test
    void assertThrowsException()
    {
        assertThrows(IllegalArgumentException.class, () -> {
            Integer.valueOf(null);
        });
    }

    @Test
    void shouldThrowExceptionAndInspectMessage()
    {
        Throwable exception = assertThrows(UnsupportedOperationException.class, () -> {
            throw new UnsupportedOperationException("Not supported");
        });
        assertEquals(exception.getMessage(), "Not supported");
    }

    @Test
    @DisplayName("Exception test clearer")
    void exceptionTestImproved()
    {
        Executable executable = () -> {
            throw new UnsupportedOperationException("Not supported");
        };

        Throwable exception = assertThrows(UnsupportedOperationException.class, executable);

        assertEquals(exception.getMessage(), "Not supported");
    }
}
