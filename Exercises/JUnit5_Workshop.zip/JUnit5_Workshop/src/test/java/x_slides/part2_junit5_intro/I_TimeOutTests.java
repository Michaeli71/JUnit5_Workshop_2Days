package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;

import java.time.Duration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.ThrowingSupplier;

import exercises.part2.Ex02_LongRunner;
import utils.FibonacciCalculator;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class I_TimeOutTests
{    
    @Test
    void testFibRecWithBigNumber()
    {
        long value = FibonacciCalculator.fibRec(47);
        
        assertEquals(2971215073L, value);
    }
    
    @Test
    void testFibRecWithBigNumber_Timeout()
    {
        assertTimeout(Duration.ofSeconds(2), 
                      () -> FibonacciCalculator.fibRec(47));
    }
    
    @Test
    void testFibRecWithBigNumber_Timeout_Preemptive()
    {
        assertTimeoutPreemptively(Duration.ofSeconds(2), 
                                  () -> FibonacciCalculator.fibRec(47));
    }
    
    @Test
    void testCalcFib30_With_Timeout_And_Result()  
    {
        // Provide result of calculation if with in time out
        ThrowingSupplier<Long> action = () -> Ex02_LongRunner.calcFib30();
        
        Long value = assertTimeoutPreemptively(Duration.ofSeconds(1), 
                                               action);
        
        assertEquals(832040, value);
    }
}
