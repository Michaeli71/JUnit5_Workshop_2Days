package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import exercises.part3.Ex04_AddOneToAnArray;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex04_AddOneToAnArrayTest
{
    @ParameterizedTest(name = "{0} + 1 => {1}")
    @MethodSource("intArrays")
    void addOne(int[] input, int[] expected)
    {
        final int[] result = Ex04_AddOneToAnArray.addOne(input);

        assertArrayEquals(expected, result);
    }

    private static Stream<Arguments> intArrays()
    {
        final int[] values1 = { 1, 3, 2, 4 };
        final int[] expected1 = { 1, 3, 2, 5 };

        final int[] values2 = { 1, 4, 8, 9 };
        final int[] expected2 = { 1, 4, 9, 0 };

        final int[] values3 = { 1, 3, 9, 9 };
        final int[] expected3 = { 1, 4, 0, 0 };

        final int[] values4 = { 9, 9, 9, 9 };
        final int[] expected4 = { 1, 0, 0, 0, 0 };

        final int[] values5 = { 9 };
        final int[] expected5 = { 1, 0 };

        return Stream.of(Arguments.of(values1, expected1), Arguments.of(values2, expected2),
                         Arguments.of(values3, expected3), Arguments.of(values4, expected4),
                         Arguments.of(values5, expected5));
    }
}