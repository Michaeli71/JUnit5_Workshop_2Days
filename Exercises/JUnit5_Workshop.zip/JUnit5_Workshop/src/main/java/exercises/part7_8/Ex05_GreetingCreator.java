package exercises.part7_8;

import java.time.LocalTime;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_GreetingCreator
{
    public String createGreeting(final LocalTime time)
    {
        String message = "Good ";
        if (time.isBefore(LocalTime.of(12, 0, 0)))
        {
            message += "Morning";
        }
        else if (time.isAfter(LocalTime.of(12, 0, 0)))
        {
            message += "Afternoon";
        }
        else if (time.isAfter(LocalTime.of(18, 0, 0)))
        {
            message += "Evening";
        }
        
        return message;
    }
}
