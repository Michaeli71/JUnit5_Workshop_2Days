package a_powermockito_intro_examples;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class PrivateMethoExampleTest
{   
    @PrepareForTest(PrivateMethodExample.class)
    @Test 
    public void testPrivateMethod() throws Exception
    {
        PrivateMethodExample spy = PowerMockito.spy(new PrivateMethodExample());
        PowerMockito.when(spy, "privateMethod").thenReturn("CHANGED");
        
        String result = spy.getValue();
        
        assertEquals("CHANGED", result);
    }
}
