package exercises;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
public class Ex04_ServiceWithDependencyTest
{
    @Test
    // TODO
    public void testModifiyResultOfFinalMethod()
    {
        // TODO
        Ex04_SystemStateService stateService = new Ex04_SystemStateService();
        // TODO

        Ex04_ServiceWithDependency service = new Ex04_ServiceWithDependency();        
        boolean systemIsAlive = service.callFinalMethod(stateService);        
        
        assertTrue(systemIsAlive);
    }
}