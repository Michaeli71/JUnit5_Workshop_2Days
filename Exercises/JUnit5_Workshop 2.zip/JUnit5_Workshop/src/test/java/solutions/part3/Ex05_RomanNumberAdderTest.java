package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 *         Copyright 2019 by Michael Inden
 */
public class Ex05_RomanNumberAdderTest
{
    @ParameterizedTest(name = "{0} + {1} => {2}    (Berechnung: {3})")
    @CsvFileSource(resources = "roman-addition.csv", numLinesToSkip = 2)
    @DisplayName("Addiere römische Zahlen")
    void addRomanNumber(String romanNumber1, String romanNumber2, String expected, String hint)
    {
        final String result = Ex05_RomanNumberAdder.addRomanNumber(romanNumber1, romanNumber2);
        
        assertEquals(expected, result);
    }
    
    @ParameterizedTest(name = "{0} - {1} => {2}    (Berechnung: {3})")
    @CsvFileSource(resources = "roman-subtraction.csv", numLinesToSkip = 2)
    @DisplayName("Subtrahiere römische Zahlen")
    void subtractRomanNumber(String romanNumber1, String romanNumber2, String expected, String hint)
    {
        final String result = Ex05_RomanNumberAdder.subtractRomanNumber(romanNumber1, romanNumber2);
        
        assertEquals(expected, result);
    }
}