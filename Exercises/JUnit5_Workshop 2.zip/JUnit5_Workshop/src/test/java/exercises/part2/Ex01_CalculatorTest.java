package exercises.part2;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex01_CalculatorTest 
{
    @Test
    void test_add_normal_numbers()
    {
       // TODO
    }

    @Test
    void test_add_same_positive_and_negative_numbers_should_sum_to_zero()
    {
        // TODO
    }

    @Test
    void test_divide_by_zero_should_raise_exception()
    {
        // TODO
    }

    // TODO
}