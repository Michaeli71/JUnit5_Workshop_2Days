package solutions.part3;

import exercises.part3.Ex05_RomanNumbers;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_RomanNumberAdder
{
    public static String addRomanNumber(final String romanNumber1, final String romanNumber2)
    {
        final int result = Ex05_RomanNumbers.fromRomanNumber(romanNumber1) +
                           Ex05_RomanNumbers.fromRomanNumber(romanNumber2);

        return Ex05_RomanNumbers.toRomanNumber(result);
    }
    
    public static String subtractRomanNumber(final String romanNumber1, final String romanNumber2)
    {
        final int result = Ex05_RomanNumbers.fromRomanNumber(romanNumber1) -
                           Ex05_RomanNumbers.fromRomanNumber(romanNumber2);

        return Ex05_RomanNumbers.toRomanNumber(result);
    }
}
