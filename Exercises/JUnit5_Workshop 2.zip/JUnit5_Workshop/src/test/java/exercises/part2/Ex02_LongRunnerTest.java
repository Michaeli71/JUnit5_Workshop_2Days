package exercises.part2;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex02_LongRunnerTest
{
    @Test
    public void testCalcFib45() throws Exception
    {
        assertEquals(1134903170, Ex02_LongRunner.calcFib45());
    }

    @Test
    public void testToUpper() throws Exception
    {
        final String expected = "HELLO JUGS BERN";
        
        final String actual = Ex02_LongRunner.toUpper("hello JUGS bern");
        
        assertEquals(expected, actual, Ex02_LongRunner.createErrorMessage("JUGS"));
    }
}
