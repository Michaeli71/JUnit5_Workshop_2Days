package easymock_intro;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class IncomeCalculator 
{
	private final SalaryService salaryService;
	
	public IncomeCalculator(final SalaryService salaryService)
	{
		this.salaryService = salaryService;
	}

	public int getIncomePerMonth(final Position position) 
	{
        return salaryService.salaryForPosition(position) / 12;
    }
}