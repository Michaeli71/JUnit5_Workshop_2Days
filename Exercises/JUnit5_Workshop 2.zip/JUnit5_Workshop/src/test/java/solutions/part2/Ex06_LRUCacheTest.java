package solutions.part2;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import exercises.part2.Ex06_LRUCache;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@TestMethodOrder(OrderAnnotation.class)
class Ex06_LRUCacheTest
{
    static Ex06_LRUCache<String, Integer> cache;
    
    @Test
    void test()
    {
        cache = new Ex06_LRUCache<String, Integer>(4)
        {{
            put("Peter", 1);
            put("Mike", 2);
            put("Tim", 3);
            put("James", 4);
        }};

        // sollte erstes Element verdrängen
        cache.put("Tom", 5);
        
        assertNull(cache.get("Peter"));

        // sollte weitere zwei Elemnte verdrängen
        cache.put("Fritz", 6);
        cache.put("Franz", 7);
        
        assertNull(cache.get("Mike"));
        assertNull(cache.get("Tim"));
    }

    @Test
    void testIntersectWithGets()
    {
        cache = new Ex06_LRUCache<String, Integer>(4)
        {{
            put("Peter", 1);
            put("Mike", 2);
            put("Tim", 3);
            put("James", 4);
        }};

        cache.put("Tom", 5);    // Peter raus
        cache.get("Mike");      // 
        cache.get("Tim");       // 
        cache.put("Karthi", 5); // James raus

        // TODO
        assertNull(cache.get("Peter"));
        assertNull(cache.get("James"));
        assertNotNull(cache.get("Mike"));
        assertNotNull(cache.get("Tim"));
    }


    // => JUnit 5
    
    @BeforeAll
    static void initCache()
    {
        cache = new Ex06_LRUCache<String, Integer>(4)
        {{
            put("Peter", 1);
            put("Mike", 2);
            put("Tim", 3);
            put("James", 4);           
        }};
    }
    
    @Test
    @Order(1)
    void afterPutElementBeneathCapacityFirstShoudlBeRemoved()
    {
        cache.put("Tom", 5);
        
        assertNull(cache.get("Peter"));
    }
    
    @Test
    @Order(2)
    void testTwoMoreEntries()
    {
        cache.put("Fritz", 6);
        cache.put("Franz", 7);
        
        assertAll(() -> assertNull(cache.get("Mike")),
                  () -> assertNull(cache.get("Tim")));
    }
    
    @Test
    void testIntersectWithGetsV5()
    {
        initCache();
        
        // sollte erstes Element verdrängen
        cache.put("Tom", 5);    // Peter raus
        cache.get("Mike");      // 
        cache.get("Tim");       // 
        cache.put("Karthi", 5); // James raus

        assertAll(() -> assertNull(cache.get("Peter")),
                  () -> assertNull(cache.get("James")),
                  () -> assertNotNull(cache.get("Mike")),
                  () -> assertNotNull(cache.get("Tim")));
    }
}
