package exercises;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.Point;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
// TODO
public class Ex02_PointFactoryTest
{
    @Test
    public void testPointInstantiation() throws Exception
    {        
        // TODO

        Ex02_PointFactory factory = new Ex02_PointFactory();
        Point actualMockPoint = factory.create();

        assertEquals(new Point(72, 71), actualMockPoint.getLocation());
    }
}
