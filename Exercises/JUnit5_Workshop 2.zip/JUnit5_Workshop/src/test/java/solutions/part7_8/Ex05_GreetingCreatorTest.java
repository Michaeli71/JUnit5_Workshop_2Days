package solutions.part7_8;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalTime;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_GreetingCreatorTest
{
    @Test
    public void testMorning()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(11, 0, 0));
        
        assertEquals("Good Morning", greeting);
    }
    
    @Test
    public void testAfternoon()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(15, 0, 0));
        
        assertEquals("Good Afternoon", greeting);
    }

    @Test
    public void testEvening()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(20, 0, 0));
        
        assertEquals("Good Evening", greeting);
    }
    
    // was ist mit exakt 12, 15 und 18 Uhr?
    // UPS, da ging etwas an den Grenzen schief => Ergebnis ist nur "Good "
    // also keine Zuordnung
    
    @Test
    public void test12()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(12, 0, 0));
        
        assertEquals("Good Afternoon", greeting);
    }
       
    @Test
    public void test18()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(18, 0, 0));
        
        assertEquals("Good Evening", greeting);
    }
    
    @Test
    public void test24()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(0, 0, 0));
        
        assertEquals("Good Evening", greeting);
    }
    
    @Test
    public void test0_0_14()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(0, 0, 1));
        
        assertEquals("Good Morning", greeting);
    }
}
