package mutation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

// https://www.oracle.com/corporate/features/mutation-testing.html
public class SpecialCounterTest
{
    // VERY BAD "TEST" ... 100% Coverage, aber KEINE semantische Prüfung
    @Test
    @DisplayName("Boss says he wants 100% coverage. Here you go!")
    public void veryBadTrickyAssertNothing()
    {
        SpecialCounter counter = new SpecialCounter();

        counter.reset();
        counter.countIfHundredOrAbove(111);
        counter.countIfHundredOrAbove(99);

        counter.currentCount();
    }

    // normalerweise werden wir so etwas (hoffentlich) nicht machen
    // Wandle dies in richtige Tests um (könnte Übungsaufgabe sein)

    @Test
    void startsWithEmptyCount()
    {
        SpecialCounter counter = new SpecialCounter();

        assertEquals(0, counter.currentCount());
    }

    @Test
    void countsLargeNumbersCorrectly()
    {
        SpecialCounter counter = new SpecialCounter();

        counter.countIfHundredOrAbove(111);
        counter.countIfHundredOrAbove(333);

        assertEquals(2, counter.currentCount());
    }

    @Test
    void doesNotCountIntegersBelowHundred()
    {
        SpecialCounter counter = new SpecialCounter();

        counter.countIfHundredOrAbove(77);

        assertEquals(0, counter.currentCount());
    }

    @Test
    void resetSetsValueToZero()
    {
        SpecialCounter counter = new SpecialCounter();

        counter.countIfHundredOrAbove(420);
        counter.reset();

        assertEquals(0, counter.currentCount());
    }

    // MUTATION TESTING FINDET DEN FEHLENDEN TEST für die Grenze

    @Test
    void countsIntegersCorrectlyForMinimumOf100()
    {
        SpecialCounter counter = new SpecialCounter();

        counter.countIfHundredOrAbove(100);

        assertEquals(1, counter.currentCount());
    }
}
