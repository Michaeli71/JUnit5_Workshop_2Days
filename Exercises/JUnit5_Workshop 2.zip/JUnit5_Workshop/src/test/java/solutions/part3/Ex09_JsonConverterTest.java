package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.converter.SimpleArgumentConverter;
import org.junit.jupiter.params.provider.CsvSource;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex09_JsonConverterTest
{
    @ParameterizedTest
    @CsvSource(value = { "{ name:'Peter', dateOfBirth: '2012-12-06', homeTown : 'Köln', hobby: 'SKATEN'} | false",
                         "{ name:'Mike', dateOfBirth: '07.02.1971', homeTown : 'Zürich', hobby: 'JAVA'} | true"}, delimiter = '|')
    void jsonPersonAdultTest(@ConvertWith(JsonToPerson.class) Person person, boolean expected)
    {
        final long age = ChronoUnit.YEARS.between(person.dateOfBirth, LocalDate.now());

        assertEquals(expected, age >= 18);
    }

//    static class JsonToType<T> extends SimpleArgumentConverter
//    {
//        private static final Gson gson = new GsonBuilder().
//                        registerTypeAdapter(LocalDate.class, new LocalDateAdapter()).
//                        create();
//
//        @Override
//        public T convert(Object source, Class<?> targetType) 
//        {
//            return gson.fromJson((String) source, targetType.getClass());
//        }
//    }
    
static class JsonToPerson extends SimpleArgumentConverter
{
    private static final Gson gson = new GsonBuilder().
                    registerTypeAdapter(LocalDate.class, new LocalDateAdapter()).
                    create();

    @Override
    public Person convert(Object source, Class<?> targetType) 
    {
        return gson.fromJson((String) source, Person.class);
    }
}

    static final class LocalDateAdapter extends TypeAdapter<LocalDate>
    {
        @Override
        public void write(final JsonWriter jsonWriter, final LocalDate localDate) throws IOException
        {
            jsonWriter.value(localDate.toString());
        }

        @Override
        public LocalDate read(final JsonReader jsonReader) throws IOException
        {
            String dateValue = jsonReader.nextString();
            
            try {
            	return LocalDate.parse(dateValue);
            }
            catch (DateTimeParseException dtpe)
            {
            	// FALLBACK deutsches Format
            	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
            	return LocalDate.parse(dateValue, dtf);
            }            
        }
    }   
}
