package intro;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class SimpleGoogleSearch 
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");

		WebDriver driver = new FirefoxDriver();

		try
		{
    		driver.get("https://www.google.com");
    	    WebElement searchTextField = driver.findElement(By.name("q"));
            WebElement searchButton = driver.findElement(By.name("btnK"));
    	       
    	    // Aktion
    	    searchTextField.sendKeys("JUnit 5");
    	        	    
    	    //searchButton.click();
    	    searchButton.submit();
    	        
    	    Thread.sleep(5000);
    		int count = searchFor(driver, "Selenium");
    		System.out.println("Result count:" + count);
    
    		count = searchForV2(driver, "Java-Profi");
    		System.out.println("Result count:" + count);
		}
		finally
		{
		    driver.quit();
		}
	}

	public static int searchFor(WebDriver driver, String searchQuery) throws InterruptedException {

		driver.get("https://www.google.com");

		WebElement searchTextField = driver.findElement(By.name("q"));
		driver.findElement(By.name("btnK"));

		// Aktion
		searchTextField.sendKeys(searchQuery + Keys.ENTER);
		// so geht es nicht, da die Drop Down Liste angezeigt wird
		// searchTextField.sendKeys(searchQuery);
		// searchButton.click();

		// Neue Seite
		(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("rcnt")));

		List<WebElement> results = driver.findElements(By.className("rc"));
		// Print the result count
		return results.size();
	}

	public static int searchForV2(WebDriver driver, String searchQuery) throws InterruptedException {

		driver.get("http://www.google.com");
		WebElement element = driver.findElement(By.name("q"));
		element.sendKeys(searchQuery + "\n");  
		element.submit();

		(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("rcnt")));

		List<WebElement> results = driver.findElements(By.xpath("//*[@id='rso']//a"));

		// this are all the links you like to visit
		for (WebElement webElement : results) {
			System.out.println(webElement.getAttribute("href"));
		}

		return results.size();
	}
}
