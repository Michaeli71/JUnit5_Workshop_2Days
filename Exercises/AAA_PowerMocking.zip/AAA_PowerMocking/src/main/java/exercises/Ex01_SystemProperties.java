package exercises;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public /*final*/ class Ex01_SystemProperties
{
    public String getSystemProperty(String propertyName)
    {
        return System.getProperty(propertyName);
    }
}
