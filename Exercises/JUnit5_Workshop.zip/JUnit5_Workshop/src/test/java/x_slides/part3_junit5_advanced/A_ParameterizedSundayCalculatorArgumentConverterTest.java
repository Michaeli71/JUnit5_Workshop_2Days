package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ParameterContext;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ArgumentConversionException;
import org.junit.jupiter.params.converter.ArgumentConverter;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import utils.SundayCalculator;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_ParameterizedSundayCalculatorArgumentConverterTest {

	@Test
	void sundaysBetween() {
		final LocalDate start = LocalDate.of(2020, 1, 1);
		final LocalDate end = LocalDate.of(2020, 3, 3);

		final List<LocalDate> sundays = SundayCalculator.allSundaysBetween(start, end);

		final List<LocalDate> expectedSundays = Arrays.asList(LocalDate.parse("2020-01-05"),
				LocalDate.parse("2020-01-12"), LocalDate.parse("2020-01-19"),
				LocalDate.parse("2020-01-26"), LocalDate.parse("2020-02-02"),
				LocalDate.parse("2020-02-09"), LocalDate.parse("2020-02-16"),
				LocalDate.parse("2020-02-23"), LocalDate.parse("2020-03-01"));

		assertEquals(expectedSundays, sundays);
	}

	// Mit ArgumentConverter

	@ParameterizedTest(name = "sundays between {0} and {1} => {2}")
	@MethodSource("startAndEndDateAndResults")
	void sundaysBetweenWithConverter(LocalDate start, LocalDate end,
			@ConvertWith(ToLocalDateListConverter.class) List<LocalDate> expected) 
	{
		final List<LocalDate> result = SundayCalculator.allSundaysBetween(start, end);

		assertEquals(expected, result);
	}

	private static Stream<Arguments> startAndEndDateAndResults()
	{
	    return Stream.of(Arguments.of(LocalDate.of(2020, 1, 1), LocalDate.of(2020, 3, 3),
	                                  List.of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26", "2020-02-02",
	                                          "2020-02-09", "2020-02-16", "2020-02-23", "2020-03-01")),
	                     Arguments.of(LocalDate.of(1971, 2, 1), LocalDate.of(1971, 3, 1),
	                                  List.of("1971-02-07", "1971-02-14", "1971-02-21", "1971-02-28")),
	                     Arguments.of(LocalDate.of(2020, 4, 1), LocalDate.of(2020, 5, 1),
	                                  List.of("2020-04-05", "2020-04-12", "2020-04-19", "2020-04-26")));
	}
	
	static class ToLocalDateListConverter implements ArgumentConverter 
	{
		@Override
		public Object convert(Object source, ParameterContext context) throws ArgumentConversionException 
		{
			// leider nicht prüfbar, ob List<String>
			if (source instanceof List) 
			{
				return convertToLocalDates((List<String>) source);
			}
			throw new ArgumentConversionException(source + " is no list");
		}
	}

    private static List<LocalDate> convertToLocalDates(final List<String> datesAsStings)
    {
        return datesAsStings.stream().map(day -> LocalDate.parse(day)).collect(Collectors.toList());
    }
	
	// Bonus spezieller Argument Converter aus List / Array String Repräsentation

	static class FromStringArrayConverter implements ArgumentConverter {
		@Override
		public Object convert(Object source, ParameterContext context) throws ArgumentConversionException {
			if (source instanceof String) {
				final String input = (String) source;
				final String payload = input.substring(1, input.length() - 1);

				final String[] data = payload.split(",");
				return Arrays.stream(data).map(str -> str.trim()). //
						map(str -> LocalDate.parse(str)). //
						collect(Collectors.toList());
			}
			throw new ArgumentConversionException(source + " is no string");
		}
	}

	@ParameterizedTest(name = "sundays between {0} and {1} => {2}")
	@MethodSource("startAndEndDateAndArrayResults")
	void sundaysBetweenArrayBasedInput(LocalDate start, LocalDate end,
			@ConvertWith(FromStringArrayConverter.class) List<LocalDate> expected) {

		final List<LocalDate> result = SundayCalculator.allSundaysBetween(start, end);

		assertEquals(expected, result);
	}

	private static Stream<Arguments> startAndEndDateAndArrayResults() {
		return Stream.of(Arguments.of(LocalDate.of(2020, 1, 1), LocalDate.of(2020, 3, 1),
				"[2020-01-05, 2020-01-12, 2020-01-19, 2020-01-26, 2020-02-02, " +
						"2020-02-09, 2020-02-16, 2020-02-23]"),
				Arguments.of(LocalDate.of(1971, 2, 1), LocalDate.of(1971, 3, 1),
						"[1971-02-07, 1971-02-14, 1971-02-21, 1971-02-28]"),
				Arguments.of(LocalDate.of(2020, 4, 1), LocalDate.of(2020, 5, 1),
						"[2020-04-05, 2020-04-12, 2020-04-19, 2020-04-26]"));
	}
}