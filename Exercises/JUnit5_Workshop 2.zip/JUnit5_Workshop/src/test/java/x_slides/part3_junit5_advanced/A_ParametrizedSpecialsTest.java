package x_slides.part3_junit5_advanced;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_ParametrizedSpecialsTest
{
    @ParameterizedTest
    @MethodSource("createMonthsWithLength")
    void withMethodSource(Month month, int expectedLength)
    {
        assertEquals(expectedLength, month.length(false));
    }

    private static Stream<Arguments> createMonthsWithLength()
    {
        return Stream.of(Arguments.of(Month.JANUARY, 31), Arguments.of(Month.APRIL, 30));
    }

    @ParameterizedTest
    @ValueSource(strings = { "2019-08-01", "2019-08-31" })
    void convertStringToLocalDate(LocalDate localDate)
    {
        assertEquals(Month.AUGUST, localDate.getMonth());
    }

    @ParameterizedTest
    @CsvSource(value= {"APRIL:30", "JUNE:30", "JULY:31"}, delimiter = ':')
    void convertStringToMonth(Month month, int expectedLength)
    {
        assertEquals(expectedLength, month.length(false));
    }
    
    @ParameterizedTest
    @MethodSource("createPersonWithMonth")
    void ownTypeWithMethodSource(Person person, Month expectedMonth)
    {
        assertEquals(expectedMonth, person.dateOfBirth.getMonth());
    }

    private static Stream<Arguments> createPersonWithMonth()
    {
        return Stream.of(Arguments.of(new Person("Michael", 
                                                 LocalDate.of(1971, 2, 7), 
                                                 "Zürich"), "FEBRUARY"), 
                         Arguments.of(new Person("Tim", 
                                                 LocalDate.of(1971, 3, 27), 
                                                 "Kiel"), "MARCH"));
    }
    
	@ParameterizedTest
	@MethodSource("stringIntAndListProvider")
	void multipleArgumentsWithMethodSource(String str, int num, List<String> list) 
	{
	    assertEquals(5, str.length());
	    assertTrue(num < 10);
	    assertEquals(3, list.size());
	}
	
	static Stream<Arguments> stringIntAndListProvider() 
	{
	    return Stream.of(Arguments.arguments("James", 2, List.of("a", "b", "c")),
	    		         Arguments.arguments("Peter", 7, List.of("x", "y", "z")));
	}
}
