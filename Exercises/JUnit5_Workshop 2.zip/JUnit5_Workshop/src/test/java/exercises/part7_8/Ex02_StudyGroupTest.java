package exercises.part7_8;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_StudyGroupTest
{
    @Test
    public void testStudyGroupClass()
    {
        final List<Ex02_Student> testStudents = new ArrayList<>();
        testStudents.add(new Ex02_Student(1, "Student No.1", 60));
        testStudents.add(new Ex02_Student(2, "Student No.2", 70));
        testStudents.add(new Ex02_Student(3, "Student No.2", 80));

        final Ex02_StudyGroup testGroup = new Ex02_StudyGroup();
        for (Ex02_Student student : testStudents)
        {
            testGroup.addStudent(student);
        }
        assertEquals(testStudents.size(), testGroup.getGroupSize());

        Ex02_Student testStudent = testStudents.get(0);
        Ex02_Student returnedStudent = testGroup.getStudentById(testStudent.getId());
        
        assertEquals(returnedStudent.getId(), testStudent.getId());
        assertEquals(returnedStudent.getName(), testStudent.getName());
        assertEquals(returnedStudent.getScore(), testStudent.getScore());

        testGroup.removeStudent(testStudent.getId());
        assertEquals(testStudents.size() - 1, testGroup.getGroupSize());

        testGroup.clear();
        assertEquals(0, testGroup.getGroupSize());
    }
}