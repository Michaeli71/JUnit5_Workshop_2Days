package exercises;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.suppress;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Factory.class)
public class FactoryTest
{
    @Test
    public void testFactory() throws Exception 
    {
        mockStatic(Factory.class, Mockito.CALLS_REAL_METHODS);
        suppress(method(Factory.class, "checkString", String.class));
        
        String s = Factory.factorObject();
        
        //verifyPrivate(Factory.class, times(1)).invoke("checkString", anyString()); 
        assertEquals("Hello HOCHSCHULSTART", s);      
    }
}