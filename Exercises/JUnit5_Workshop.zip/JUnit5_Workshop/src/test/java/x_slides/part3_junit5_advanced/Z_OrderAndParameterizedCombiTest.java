package x_slides.part3_junit5_advanced;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@TestMethodOrder(OrderAnnotation.class)
public class Z_OrderAndParameterizedCombiTest
{
    static Integer commonState = 0;
    
    @Order(1)
    @ParameterizedTest(name = "{index}: {0} + {1} = {2}")
    @CsvSource({ "1,2,3", "3, -3, 0", "7, 2, 9", "7,-2,5", "9, 2, 11" })
    void addition(int a, int b, int expected) 
    {
        int sum = a + b;
        commonState += sum;
        
        assertEquals(expected, sum);
    }
    
    @Order(2)
    @Test
    void precheck() 
    {
        assertEquals(28, commonState.intValue());
    } 
    
    @Order(3)
    @ParameterizedTest(name = "{index}: {0} + {1} = {2}")
    @CsvSource({ "1,2,2", "3, -3, -9", "7, 2, 14", "7,-2,-14" })
    void multiplication(int a, int b, int expected) 
    {
        int result = a * b;
        commonState += result;
        
        assertEquals(expected, result);
    }

    @Order(4)
    @Test
    void postcheck() 
    {
        assertEquals(21, commonState.intValue());
    } 
    
    @Order(5)
    @Test
    void finalAct() 
    {
        commonState += 35;
    }
    
    @Order(6)
    @Test
    void finalCheck() 
    {
        assertEquals(56, commonState.intValue());
    }    
}
