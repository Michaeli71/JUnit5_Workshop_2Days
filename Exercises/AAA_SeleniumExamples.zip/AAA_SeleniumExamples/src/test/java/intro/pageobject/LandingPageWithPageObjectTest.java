package intro.pageobject;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LandingPageWithPageObjectTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
    }

    @BeforeEach
    public void setUp()
    {
        driver = new FirefoxDriver();
    }

    @AfterEach
    public void tearDown()
    {
        driver.quit();
    }

    @Test
    public void testLandingpageFunctionality() throws InterruptedException
    {
        // ARRANGE
        LandingPage landingPage = loginWithCredentials("Peter", "Lustig");

        // ACT
        landingPage.chooseColor(LandingPage.Color.BLUE);

        landingPage.chooseRadioOption(2);

        // Alter Stil ohne Pageobject
        WebElement check1 = driver.findElement(By.id("check-1"));
        check1.click();
        Thread.sleep(1_000);

        // ASSERT
        // ... 
    }

    private LandingPage loginWithCredentials(String name, String pwd)
    {
        return new LoginPage(driver).login(name, pwd);
    }

    @Test
    public void testLogoutFunctionality() throws InterruptedException
    {
        LandingPage landingPage = loginWithCredentials("Peter", "Lustig");

        // ACT
        landingPage.chooseRadioOption(1);

        // Auch möglich, aber schlechter Stil
        WebElement check1 = driver.findElement(By.id("check-1"));
        check1.click();

        LoginPage loginPageAgain = landingPage.clickLogout();

        // ASSERT
        assertTrue(loginPageAgain.isLoadedCorrectly());
    }

}