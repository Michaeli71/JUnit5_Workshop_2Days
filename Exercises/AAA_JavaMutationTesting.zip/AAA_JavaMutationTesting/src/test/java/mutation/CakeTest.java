package mutation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import mutation.Cake.CakeType;

//https://blog.scottlogic.com/2017/09/25/mutation-testing.html
/*
 * This is all excellent, you have test scenarios for each of the different types 
 * of cake and you’ve run your code coverage tool and you have 100% line coverage. 
 * So you are left with the warm fuzzy feeling that comes with the knowledge that 
 * your functionality is fully tested and if it is ever broken in the future a test 
 * will fail to alert the developer. But is this confidence misplaced? The more astute 
 * amongst you will have realised that I would not have included this example if there 
 * was not a deliberate mistake in it so let’s take a look at what a mutation test run makes of this code:
 */
public class CakeTest {

	@Test
	public void canCreateVictoriaSponge() {
		Cake actual = Cake.createCake(CakeType.VICTORIA_SPONGE);
		assertEquals(100, actual.getMargarineWeight());
		assertEquals(100, actual.getFlour());
		assertEquals(100, actual.getSugar());
		assertEquals(2, actual.getEggCount());
		assertEquals(0, actual.getOrangeJuiceVolume());
	}

	@Test
	public void canCreateChocolateCake() {
		Cake actual = Cake.createCake(CakeType.CHOCOLATE);
		assertEquals(100, actual.getMargarineWeight());
		assertEquals(25, actual.getCocoaWeight());
		assertEquals(100, actual.getSugar());
		assertEquals(2, actual.getEggCount());
		assertEquals(0, actual.getOrangeJuiceVolume());
	}

	@Test
	public void canCreateOrangeCake() {
		Cake actual = Cake.createCake(CakeType.ORANGE);
		assertEquals(100, actual.getMargarineWeight());
		assertEquals(100, actual.getFlour());
		assertEquals(100, actual.getSugar());
		assertEquals(2, actual.getEggCount());
		assertEquals(15, actual.getOrangeJuiceVolume());
	}

}
