package selenium.exercises;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex03_GoogleSearchAsTest
{
    WebDriver driver;

    @BeforeAll
    public static void init()
    {
        // TODO
    }
        
    @Test
    public void testGoogleSearch()
    {
        driver.get("http://www.google.com");

        // TODO        
    }
}