package easymock_intro;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.createNiceMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class IncomeCalculatorTest 
{
	@Test
	public void testWithNiceMock() 
	{
		// ARRANGE
		SalaryService salaryService = createNiceMock(SalaryService.class);
		IncomeCalculator incomeCalculator = new IncomeCalculator(salaryService);
	
		expect(salaryService.salaryForPosition(Position.ARCHITECT)).andReturn(100000).times(2);
	    expect(salaryService.salaryForPosition(Position.PROGRAMMER)).andReturn(60000);
	    // Setup is finished need to activate the mock
	    replay(salaryService);
	
	    // ACT 
	    int result1 = incomeCalculator.getIncomePerMonth(Position.ARCHITECT);
	    int result2 = incomeCalculator.getIncomePerMonth(Position.ARCHITECT);
	    int result3 = 5000; // incomeCalculator.getIncomePerMonth(Position.PROGRAMMER);
	    int result4 = incomeCalculator.getIncomePerMonth(Position.LEAD_DEVELOPER);  // => 0
	    String desc = salaryService.getJobDescription(); // => null
	
	    // ASSERT AND VERIFY
	    assertEquals(8333, result1);
	    assertEquals(8333, result2);
	    assertEquals(5000, result3);
	    
	    // CHECK IF EXPECTED CALLS REALLY OCCURED        
	    verify(salaryService);
	}
    
@Test
public void testWithPlainMock() 
{
	// ARRANGE
	SalaryService salaryService = createMock(SalaryService.class);
	IncomeCalculator incomeCalculator = new IncomeCalculator(salaryService);

    expect(salaryService.salaryForPosition(Position.ARCHITECT)).andReturn(100000).times(2);
    expect(salaryService.salaryForPosition(Position.PROGRAMMER)).andReturn(60000);
    // Setup is finished need to activate the mock
    replay(salaryService);

    // ACT 
    int result1 = incomeCalculator.getIncomePerMonth(Position.ARCHITECT);
    int result2 = incomeCalculator.getIncomePerMonth(Position.ARCHITECT);
    //int result3 = 5000; 
    int result3 = incomeCalculator.getIncomePerMonth(Position.PROGRAMMER);
    // Unexpected method call SalaryService.salaryForPosition(LEAD_DEVELOPER):
    // int result4 = incomeCalculator.getIncomePerMonth(Position.LEAD_DEVELOPER);  
    // Unexpected method call SalaryService.getJobDescription():
    // String desc = salaryService.getJobDescription(); // => null
    		
    // ASSERT AND VERIFY
    assertEquals(8333, result1);
    assertEquals(8333, result2);
    assertEquals(5000, result3);
    
    // CHECK IF EXPECTED CALLS REALLY OCCURED        
    verify(salaryService);
}
}