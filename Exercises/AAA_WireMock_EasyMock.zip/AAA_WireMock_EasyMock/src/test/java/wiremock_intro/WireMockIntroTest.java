package wiremock_intro;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.notMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.ok;
import static com.github.tomakehurst.wiremock.client.WireMock.okJson;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.status;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.temporaryRedirect;
import static com.github.tomakehurst.wiremock.client.WireMock.unauthorized;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;

import org.junit.Rule;
import org.junit.Test;

import com.github.tomakehurst.wiremock.junit.WireMockRule;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 *         Copyright 2020 by Michael Inden
 */
public class WireMockIntroTest {
	public void setupStub() {
		stubFor(get(urlEqualTo("/an/endpoint")).willReturn(aResponse().withHeader("Content-Type", "text/plain")
				.withStatus(200).withBody("You've reached a valid WireMock endpoint")));
	}

	@Rule
	public WireMockRule wireMockRule = new WireMockRule(8089);
	// No-args constructor defaults to port 8080 (we use this for DOCKER)

	@Test
	public void testAnEndpoint_ShouldReturn_StatusCode_200() {

		setupStub();

		when().get("http://localhost:8089/an/endpoint").then().assertThat().statusCode(200);
	}

    @Test
    public void testAnEndpoint_ShouldReturn_StatusCode_200_Http2_API() throws Exception 
    {
        setupStub();
    
        HttpResponse<String> result = performGetCall("/an/endpoint", "");
        
        assertEquals(200, result.statusCode());
    }

    @Test
    public void createUserWithPost() throws Exception 
    {
        stubFor(post(urlEqualTo("/users")).willReturn(aResponse().withStatus(201)
                .withHeader("content-type", "text/plain").withBody("User created!")));
    
        given().
        	body("<user>USER-MICHAEL</user>").
        when().
           post("http://localhost:8089/users").
        then().
           assertThat().
           statusCode(201).
        and().
        	assertThat().body(equalTo("User created!"));
    
        verify(postRequestedFor(urlMatching("/users")).
               withRequestBody(matching(".*USER.*")).
               withHeader("Content-Type", notMatching("application/json")));
    }
	   
    @Test
    public void createUserWithPost_Http2_API() throws Exception 
    {
    	stubFor(post(urlEqualTo("/users")).willReturn(aResponse().withStatus(201)
    			.withHeader("content-type", "text/plain").withBody("User created!")));
    
    	HttpResponse<String> result = performPostWithXmlBody("/users", "USER-MICHAEL");
    	assertEquals(201, result.statusCode());
    	assertEquals("User created!", result.body());
    
    	verify(postRequestedFor(urlMatching("/users")).
    	       withRequestBody(matching(".*USER.*")).
    	       withHeader("Content-Type", notMatching("application/json")));
    }

	
	
	
	static HttpResponse<String> performGetCall(String path, String contentType)
			throws IOException, InterruptedException {
		if (contentType == null || contentType.isEmpty())
			contentType = "text/plain";

		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = HttpRequest.newBuilder().uri(URI.create("http://localhost:8089" + path))
				.header("Content-Type", contentType).build();

		return client.send(request, BodyHandlers.ofString());
	}

	static HttpResponse<String> performPostWithXmlBody(String path, String content)
			throws IOException, InterruptedException {
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest request = HttpRequest.newBuilder().uri(URI.create("http://localhost:8089" + path))
				.POST(HttpRequest.BodyPublishers.ofString(content)).header("Content-Type", "text/xml")
				.header("Accept", "text/xml").build();

		return client.send(request, BodyHandlers.ofString());
	}

	@Test
	public void abbreviations() 
	{
		stubFor(delete("/fine").willReturn(ok()));

		stubFor(get("/fine-with-body").willReturn(ok("body content")));

		stubFor(get("/json").willReturn(okJson("{ \"message\": \"Hello\" }")));

		stubFor(post("/redirect").willReturn(temporaryRedirect("/new/place")));

		stubFor(post("/sorry-no").willReturn(unauthorized()));

		stubFor(put("/status-only").willReturn(status(418)));
	}
}
