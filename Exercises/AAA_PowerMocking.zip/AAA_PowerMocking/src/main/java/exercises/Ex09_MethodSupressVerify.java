package exercises;
/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex09_MethodSupressVerify
{
    public Ex09_MethodSupressVerify()
    {
    }

    public int calc(final String name)
    {
       	return 42;
    }
    
    public static int staticMethod(final String name)
    {
       	return 77;
    }    
}