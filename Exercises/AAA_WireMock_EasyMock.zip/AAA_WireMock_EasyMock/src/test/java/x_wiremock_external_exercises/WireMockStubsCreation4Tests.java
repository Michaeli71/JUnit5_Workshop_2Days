package x_wiremock_external_exercises;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.junit.Rule;
import org.junit.Test;

import com.github.tomakehurst.wiremock.junit.WireMockRule;

//https://www.ontestautomation.com/open-sourcing-my-workshop-on-wiremock/
public class WireMockStubsCreation4Tests {
	
	WireMockStubsCreation4 wma = new WireMockStubsCreation4();
	
	@Rule
	public WireMockRule wireMockRule = new WireMockRule(9876);
	
	@Test
	public void testExercise401() {
		
		String url = "http://localhost:9876/exercise401";
        
	    wma.setupStub12();
	         
	    given().
	    when().
	        get(url).
	    then().
	    	assertThat().
	    	statusCode(200).
	    and().
	    	body(equalTo("No light bulb found"));
	    
	    given().
	    	body("Insert light bulb").
	    when().
	        post(url).
	    then().
	    	assertThat().
	    	statusCode(200).
	    and().
	    	body(equalTo("Light bulb inserted"));
	    
	    given().
	    when().
	        get(url).
	    then().
	    	assertThat().
	    	statusCode(200).
	    and().
	    	body(equalTo("Light is OFF"));
	    
	    given().
	    	body("Switch light ON").
	    when().
	        post(url).
	    then().
	    	assertThat().
	    	statusCode(200).
	    and().
	    	body(equalTo("Light has been turned ON"));
	    
	    given().
	    when().
	        get(url).
	    then().
	    	assertThat().
	    	statusCode(200).
	    and().
	    	body(equalTo("Light is ON"));
	}
}