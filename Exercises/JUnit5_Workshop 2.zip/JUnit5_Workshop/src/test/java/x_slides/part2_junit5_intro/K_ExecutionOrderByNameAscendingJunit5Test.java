package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.MethodOrderer.MethodName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@TestMethodOrder(MethodName.class)
public class K_ExecutionOrderByNameAscendingJunit5Test
{
    private static final StringBuilder result = new StringBuilder("");
    
    @Test
    public void B_secondTest() {
        result.append("b");
    }
 
    @Test
    public void C_thirdTest() {
        result.append("c");
    }
 
    @Test
    public void A_firstTest() {
        result.append("a");
    }

    @AfterAll
    public static void assertOutput()
    {
        assertEquals("abc", result.toString());
    }
}