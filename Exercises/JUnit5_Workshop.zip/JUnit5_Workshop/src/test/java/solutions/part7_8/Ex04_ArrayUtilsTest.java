package solutions.part7_8;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex04_ArrayUtilsTest
{
    @Test
    void testIndexOf_ValidValue()
    {
        int[] values = { 1, 2, 3, 4, 5 };
        
        int idx = Ex04_ArrayUtils.indexOf(values, 2);
        
        assertEquals(1, idx);
    }
    
    @Test
    void testIndexOf_NotContained_Value()
    {
        int[] values = { 1, 2, 3, 4, 5 };
        
        int idx = Ex04_ArrayUtils.indexOf(values, 7);
        
        assertEquals(-1, idx);
    }
        
    // Randfälle leeres Array
    
    @Test
    void testIndexOf_EmptyArray()
    {
        int[] values = { };
        
        int idx = Ex04_ArrayUtils.indexOf(values, 2);
        
        assertEquals(-1, idx);
    }
    
    // Randfälle NULL Array  
    
    @Test
    void testIndexOf_NullArray()
    {
        int[] values = null;
        
        Executable exec = () -> Ex04_ArrayUtils.indexOf(values, 2);
        
        assertThrows(IllegalArgumentException.class, exec);
    }
}
