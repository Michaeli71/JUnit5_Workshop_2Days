package solutions.part2;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

import utils.CollectionUtils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex05_ArraysSortTest
{
    @Test
    void testJUnit4_Arrays_sort()
    {
        int[] values = { 7, 2, 1, 4, 5, 3, 6 };

        Arrays.sort(values);

        // sort does not change count
        assertEquals(7, values.length);
        assertEquals(1, values[0]);
        assertEquals(2, values[1]);
        assertEquals(3, values[2]);
        assertEquals(4, values[3]);
        assertEquals(5, values[4]);
        assertEquals(6, values[5]);
        assertEquals(7, values[6]);
    }

    @Test
    void testJUnit4_Collections_sort()
    {
        List<Integer> values = Arrays.asList(7, 2, 1, 4, 5, 3, 6);

        Collections.sort(values);

        // sort does not change count
        assertEquals(7, values.size());
        assertEquals(1, values.get(0));
        assertEquals(2, values.get(1));
        assertEquals(3, values.get(2));
        assertEquals(4, values.get(3));
        assertEquals(5, values.get(4));
        assertEquals(6, values.get(5));
        assertEquals(7, values.get(6));
    }

    @Test
    void testRemoveDuplicatesNoneJUnit4()
    {
        List<Integer> values = Arrays.asList(7, 6, 5, 4, 1, 2, 3);

        List<Integer> noDuplicates = CollectionUtils.listRemoveDuplicates(values);

        // sort does not change count
        assertEquals(7, noDuplicates.size());
        assertEquals(7, noDuplicates.get(0));
        assertEquals(6, noDuplicates.get(1));
        assertEquals(5, noDuplicates.get(2));
        assertEquals(4, noDuplicates.get(3));
        assertEquals(1, noDuplicates.get(4));
        assertEquals(2, noDuplicates.get(5));
        assertEquals(3, noDuplicates.get(6));
    }
    
    @Test
    void testRemoveDuplicatesJUnit4()
    {
        List<Integer> values = Arrays.asList(7, 2, 1, 2, 2, 1, 7);

        List<Integer> noDuplicates = CollectionUtils.listRemoveDuplicates(values);

        // sort does not change count
        assertEquals(3, noDuplicates.size());
        assertEquals(7, noDuplicates.get(0));
        assertEquals(2, noDuplicates.get(1));
        assertEquals(1, noDuplicates.get(2));
    }
    
    // => JUnit 5 

    @Test
    void testJUnit5_Arrays_sort()
    {
        int[] values = { 7, 2, 1, 4, 5, 3, 6 };
        int[] expected = { 1, 2, 3, 4, 5, 6, 7 };

        Arrays.sort(values);

        assertAll(// sort does not change count
                  () -> assertEquals(7, values.length), 
                  () -> assertArrayEquals(expected, values));
    }

    @Test
    void testJUnit5_Collections_sort()
    {
        List<Integer> values = Arrays.asList(7, 2, 1, 4, 5, 3, 6);
        List<Integer> expected = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
        
        Collections.sort(values);
        
        assertAll(// sort does not change count
                  () -> assertEquals(7, values.size()),
                  () -> assertIterableEquals(expected, values));
    }

    @Test
    void testRemoveDuplicatesNoneJUnit5()
    {
        List<Integer> values = Arrays.asList(7, 6, 5, 4, 1, 2, 3);
        List<Integer> expected = values;

        List<Integer> noDuplicates = CollectionUtils.listRemoveDuplicates(values);

        assertEquals(expected, noDuplicates);
    }
    
    @Test
    void testRemoveDuplicatesJUnit5()
    {
        List<Integer> values = Arrays.asList(7, 2, 1, 2, 2, 1, 7);
        List<Integer> expected = Arrays.asList(7, 2, 1);

        List<Integer> noDuplicates = CollectionUtils.listRemoveDuplicates(values);

// Possible         
/*
        assertAll(() -> assertEquals(3, noDuplicates.size()),
                  () -> assertIterableEquals(expected, noDuplicates));
*/
        // Better
        assertEquals(expected, noDuplicates);
    }
}
