
package intro.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LoginPage
{
    private static final By USERNAME_FIELD = By.id("loginForm:username");

    private static final By PASSWORD_FIELD = By.id("loginForm:password");

    private static final By LOGIN_BUTTON   = By.id("loginForm:login");

    private final WebDriver driver;

    public LoginPage(WebDriver driver)
    {
        this.driver = driver;
        this.driver.get("file:///Users/michaeli/Desktop/LoginPage.html");
    }

    public LandingPage login(String name, String password) 
    {
        driver.findElement(USERNAME_FIELD).sendKeys(name);
        driver.findElement(PASSWORD_FIELD).sendKeys(password);
        try
        {
            Thread.sleep(1_000);
        }
        catch (InterruptedException e)
        {
        }
        driver.findElement(LOGIN_BUTTON).click();
        
        return new LandingPage(driver);
    }
    
    public boolean isLoadedCorrectly()
    {
        System.out.println(driver.getCurrentUrl());
        return driver.getCurrentUrl().contains("LoginPage");
    }
}
