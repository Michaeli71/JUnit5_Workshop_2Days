package intro.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LandingPage
{
    enum Color { RED, GREEN, BLUE, PURPLE }
    
    private WebDriver     driver;

    public LandingPage(WebDriver driver)
    {
        this.driver = driver;
        this.driver.get("file:///Users/michaeli/Desktop/LandingPage.html");
    }

    public boolean isLoadedCorrectly()
    {
        System.out.println(driver.getCurrentUrl());
        return driver.getCurrentUrl().contains("LandingPage");
    }
    
    public void chooseRadioOption(int nr)
    {
        if (nr >= 1 && nr <= 3)
        {            
            WebElement radio = driver.findElement(By.id("radio-"+nr));
            radio.click();
        }
        else
        {
            System.out.println("Element " + nr + " not found");
        }
    }
    
    public void chooseColor(Color colorToChoose)
    {
        Select select = new Select(driver.findElement(By.id("colors")));
        select.selectByValue(colorToChoose.name().toLowerCase());        
    }
    
    public LoginPage clickLogout()
    {
        WebElement logoutBtn = driver.findElement(By.id("Logout"));
        logoutBtn.click();
        
        return new LoginPage(driver);
    }
}