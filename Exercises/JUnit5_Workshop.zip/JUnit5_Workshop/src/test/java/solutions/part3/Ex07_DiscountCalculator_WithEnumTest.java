package solutions.part3;

import static org.junit.Assert.assertEquals;

import java.util.stream.Stream;

import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

import exercises.part3.Discounts;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex07_DiscountCalculator_WithEnumTest
{
    @Test
    public void testCalcDiscountNo()
    {
        Ex07_DiscountCalculator_WithEnum calc = createCalculator();

        Discounts result = calc.calcDiscount(25);

        assertEquals(Discounts.NO_DISCOUNT, result);
    }

    @Test
    public void testCalcDiscountMedium()
    {
        Ex07_DiscountCalculator_WithEnum calc = createCalculator();

        Discounts result = calc.calcDiscount(1000);

        assertEquals(Discounts.MEDIUM_DISCOUNT, result);
    }

    @Test
    public void testCalcDiscountHigh()
    {
        Ex07_DiscountCalculator_WithEnum calc = createCalculator();

        Discounts result = calc.calcDiscount(2000);

        assertEquals(Discounts.HIGH_DISCOUNT, result);
    }

    // =>

    @ParameterizedTest(name = "value {0} should result in discount of {1}")
    @CsvSource({ "25, 0", "100, 4", "2000, 7" })
    public void testCalcDiscountEquivalenceClasses(int value, int expectedDiscount)
    {
        Ex07_DiscountCalculator_WithEnum calc = createCalculator();

        Discounts result = calc.calcDiscount(value);

        assertEquals(expectedDiscount, result.getDiscountValue());
    }

    // Wenn wir auf Enum vergleichen wollen, nicht auf den Wert?
    /* CSVSource nicht möglich, was also nun?? => MethodSource */
    @ParameterizedTest(name = "value {0} should result in discount of {1}")
    @MethodSource("createDiscounts")
    public void testCalcDiscountEquivalenceClasses_Imp(int value, Discounts expectedDiscount)
    {
        Ex07_DiscountCalculator_WithEnum calc = createCalculator();

        Discounts result = calc.calcDiscount(value);

        assertEquals(expectedDiscount, result);
    }

    private static Stream<Arguments> createDiscounts()
    {
        return Stream.of(Arguments.of(25, Discounts.NO_DISCOUNT), Arguments.of(100, Discounts.MEDIUM_DISCOUNT),
                         Arguments.of(2000, Discounts.HIGH_DISCOUNT));
    }

    // -----------------------------------

    private Ex07_DiscountCalculator_WithEnum createCalculator()
    {
        return new Ex07_DiscountCalculator_WithEnum();
    }

}
