package restassured_intro;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RestAssuredExamplesTest
{
	@Test
	public void makeSureThatGoogleIsUp() 
	{
		given().
		when().get("http://www.google.com").
		then().statusCode(200);
	}

	@Test
	public void testOldSchool() {

		Response response = RestAssured.get("https://reqres.in/api/users?page=2");
		System.out.println(response.statusCode());
		System.out.println(response.asString());
		System.out.println(response.getBody().asString());
		System.out.println(response.statusLine());

		int statusCode = response.getStatusCode();
		
		assertEquals(200, statusCode);
	}

    @Test
    public void test_NumberOfCircuitsFor2019Season_ShouldBe21() 
    {           
        given().
        when().
            get("http://ergast.com/api/f1/2019/circuits.json").
        then().
            assertThat().
            body("MRData.CircuitTable.Circuits.circuitId", hasSize(21));
    }
	
    @ParameterizedTest
    @CsvSource({"2017,20", "2019, 21"})
    public void test_NumberOfCircuits_Parameterized(String season, int numberOfRaces) 
    {
        given().
            pathParam("raceSeason", season).
        when().
            get("http://ergast.com/api/f1/{raceSeason}/circuits.json").
        then().
            assertThat().
            body("MRData.CircuitTable.Circuits.circuitId",hasSize(numberOfRaces));
    }
}