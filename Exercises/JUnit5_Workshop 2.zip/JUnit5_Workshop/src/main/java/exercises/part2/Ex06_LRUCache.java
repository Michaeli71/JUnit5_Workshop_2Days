package exercises.part2;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex06_LRUCache<K, V>
{
    private final Map<K, V> map;

    public Ex06_LRUCache(final int cacheSize)
    {
        map = new LinkedHashMap<K, V>(16, 0.76f, true)
        {
            protected boolean removeEldestEntry(final Map.Entry<K, V> eldest)
            {
                return size() > cacheSize;
            }
        };
    }

    public void put(final K key, final V value)
    {
        map.put(key, value);        
    }
    
    public V get(final K key)
    {
        return map.get(key);        
    }

    @Override
    public String toString()
    {
        return "LRUCache [map=" + map + "]";
    }
}
