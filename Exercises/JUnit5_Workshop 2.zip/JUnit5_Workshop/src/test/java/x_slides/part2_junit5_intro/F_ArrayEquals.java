package x_slides.part2_junit5_intro;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class F_ArrayEquals
{
    @Test
    void arraysCompare()
    {
        final String[] words = { "Word1", "Word2" };

        final String[] expected = { "Word1", "Word2" };

        assertArrayEquals(expected, words);
    }

    @Test
    void nestedArraysCompare()
    {
        final String[][] nested = { { "Line1", "Word1" }, { "Line2", "Word2" } };

        final String[][] expected = { { "Line1", "Word1" }, { "Line2", "Word2" } };

        assertArrayEquals(expected, nested);
        
    }

    @Test
    void listSetCompare()
    {
        Collection<String> tags = new HashSet<>(Arrays.asList("Fast", "Cool"));
        Collection<String> names = Arrays.asList("Tim", "Mike", "Tom");

        assertIterableEquals(Arrays.asList("Fast", "Cool"), tags);
        assertIterableEquals(Arrays.asList("Tim", "Mike", "Tom"), names);
    }
}
