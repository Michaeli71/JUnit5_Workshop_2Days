package x_slides.part5_6_dependencies_testability;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class InvalidRequestException extends Exception
{
    public InvalidRequestException(String msg)
    {
       super(msg);
    }
}
