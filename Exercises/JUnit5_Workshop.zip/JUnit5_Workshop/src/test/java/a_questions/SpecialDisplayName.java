package a_questions;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class SpecialDisplayName
{
    private static String NAME = "HELLO JUNIT";
    
    @Test
    // The value for annotation attribute DisplayName.value must be a constant expression
    //@DisplayName("FIXED " + NAME)
    //@DisplayName(createDisplayName())
    void test()
    {
        fail("Not yet implemented");
    }
    
    static String createDisplayName()
    {
        return NAME;
    }
}
