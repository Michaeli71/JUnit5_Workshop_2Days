package exercises.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ParameterContext;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ArgumentConversionException;
import org.junit.jupiter.params.converter.ArgumentConverter;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

import utils.SundayCalculator;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex08_HexConverterTest
{
    @ParameterizedTest
    @CsvSource({ "F, 15", "10, 16", "AA, 170", "FF, 255" })
    void convertWithCustomHexConverter(@ConvertWith(HexToInt.class) int input, int expected)
    {
        assertEquals(expected, input);
    }

    @ParameterizedTest
    @CsvSource({ "1, 1", "10, 2", "111, 7", "11111111, 255" })
    void convertWithCustomHBinaryConverter(@ConvertWith(BinaryToInt.class) int input, int expected)
    {
        assertEquals(expected, input);
    }

    static class HexToInt implements ArgumentConverter
    {
        @Override
        public Object convert(Object source, ParameterContext context) throws ArgumentConversionException
        {
            throw new ArgumentConversionException("Cannot convert hex value");
        }
    }

    static class BinaryToInt implements ArgumentConverter
    {
        @Override
        public Object convert(Object source, ParameterContext context) throws ArgumentConversionException
        {
            throw new ArgumentConversionException("Cannot convert hex value");
        }
    }

    @ParameterizedTest(name = "sundays between {0} and {1} => {2}")
    @MethodSource("startAndEndDateAndArrayResults")
    void sundaysBetween(LocalDate start, LocalDate end, List<LocalDate> expected)
    {
        final List<LocalDate> result = SundayCalculator.allSundaysBetween(start, end);

        assertEquals(expected, result);
    }

    private static Stream<Arguments> startAndEndDateAndArrayResults()
    {
        return Stream.of(Arguments.of(LocalDate.of(2020, 1, 1), LocalDate.of(2020, 3, 1),
                                    "[2020-01-05, 2020-01-12, 2020-01-19, 2020-01-26," + 
                                    " 2020-02-02, 2020-02-09, 2020-02-16,2020-02-23]"));
    }
}