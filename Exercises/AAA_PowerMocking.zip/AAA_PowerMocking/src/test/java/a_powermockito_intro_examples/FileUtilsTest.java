package a_powermockito_intro_examples;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;

import org.junit.Test;
import org.mockito.Mockito;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class FileUtilsTest
{
    @Test
    public void checkExistance()
    {
        // ARRANGE
        File file = Mockito.mock(File.class);
        Mockito.when(file.exists()).thenReturn(true);

        // ACT
        FileUtils demo = new FileUtils();
        boolean result = demo.checkExistance(file);
        
        // ASSERT
        assertTrue(result);
    }
}