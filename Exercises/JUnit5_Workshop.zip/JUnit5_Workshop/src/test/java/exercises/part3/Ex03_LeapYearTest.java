package exercises.part3;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex03_LeapYearTest {

	@Test
	void testIsLeap_4_Years_Rule() {
		final boolean result = Ex03_LeapYear.isLeap(2020);

		assertTrue(result);
	}

	@Test
	void testIsLeap_100_Year_Rule() {
		final boolean result = Ex03_LeapYear.isLeap(1900);

		assertFalse(result);
	}

	@Test
	void testIsLeap_400_Years_Rule() {
		final boolean result = Ex03_LeapYear.isLeap(2000);

		assertTrue(result);
	}
	
    @Test
    void test2000()
    {
        assertTrue(Ex03_LeapYear.isLeap(2000));
    }

    @Test
    void test2004()
    {
        assertTrue(Ex03_LeapYear.isLeap(2004));
    }

    @Test
    void test2012()
    {
        assertTrue(Ex03_LeapYear.isLeap(2012));
    }

    @Test
    void test1900()
    {
        assertFalse(Ex03_LeapYear.isLeap(1900));
    }

    @Test
    void test1700()
    {
        assertFalse(Ex03_LeapYear.isLeap(1700));
    }
}
