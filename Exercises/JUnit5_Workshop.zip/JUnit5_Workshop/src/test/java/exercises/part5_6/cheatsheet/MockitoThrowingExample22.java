package exercises.part5_6.cheatsheet;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.anyString;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoThrowingExample22
{
    @Test
    public void testGreetingReturnValue()
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        
        // Achtung: Reihenfolge wichtig
        when(greeting.greet(anyString())).thenReturn("Hello Mockito");
        when(greeting.greet("ERROR")).thenThrow(new IllegalArgumentException());
        // when(greeting.greet(anyString())).thenReturn("Hello Mockito");

        // Act
        final String result1 = greeting.greet("Mike");
        final String result2 = greeting.greet("ERROR");
    }

    private class Greeting
    {
        public String greet(final String name)
        {
            return "Hello " + name;
        }
    }
}
