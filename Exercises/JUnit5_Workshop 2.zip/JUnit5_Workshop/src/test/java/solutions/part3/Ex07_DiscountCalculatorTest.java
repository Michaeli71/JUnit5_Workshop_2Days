package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex07_DiscountCalculatorTest
{
    // Äquivalenzklassentests / Happy Path the old way ...

    @Test
    public void testCalcDiscountNo()
    {
        Ex07_DiscountCalculator calc = createCalculator();

        int result = calc.calcDiscount(25);

        assertEquals(0, result);
    }

    @Test
    public void testCalcDiscountMedium()
    {
        Ex07_DiscountCalculator calc = createCalculator();

        int result = calc.calcDiscount(1000);

        assertEquals(4, result);
    }

    @Test
    public void testCalcDiscountHigh()
    {
        Ex07_DiscountCalculator calc = createCalculator();

        int result = calc.calcDiscount(2000);

        assertEquals(7, result);
    }

    // =>

    @ParameterizedTest(name = "value {0} should result in discount of {1}")
    @CsvSource({ "25, 0", "100, 4", "2000, 7" })
    public void testCalcDiscountEquivalenceClasses(int value, int expectedDiscount)
    {
        Ex07_DiscountCalculator calc = createCalculator();
        
        int result = calc.calcDiscount(value);

        assertEquals(expectedDiscount, result);
    }

    // Grenzwerttests the old way ...

    @Test
    public void testCalcDiscount49()
    {
        Ex07_DiscountCalculator calc = createCalculator();
        
        int result = calc.calcDiscount(49);
        
        assertEquals(0, result);
    }

    @Test
    public void testCalcDiscount50()
    {
        Ex07_DiscountCalculator calc = createCalculator();
        
        int result = calc.calcDiscount(50);
        
        assertEquals(4, result);
    }

    @Test
    public void testCalcDiscount51()
    {
        Ex07_DiscountCalculator calc = createCalculator();
        
        int result = calc.calcDiscount(51);
        
        assertEquals(4, result);
    }

    // =>

    @ParameterizedTest(name = "{0} should be {1}")
    @CsvSource({ "49, 0", "50, 4", "51, 4" })    
    public void testCalcDiscountBorderToMedium(int value, int expectedDiscount)
    {
        Ex07_DiscountCalculator calc = createCalculator();
        
        int result = calc.calcDiscount(value);

        assertEquals(expectedDiscount, result);
    }

    @ParameterizedTest(name = "{0} should be {1}")
    @CsvSource({ "999, 4", "1000, 4", "1001, 7" })
    public void testCalcDiscountBorderToHigh(int value, int expectedDiscount)
    {
        Ex07_DiscountCalculator calc = createCalculator();
        
        int result = calc.calcDiscount(value);

        assertEquals(expectedDiscount, result);
    }
        
 
    // Fehlerfälle the old way
    @Test(expected = IllegalArgumentException.class)
    public void testThatNegativeValueReturnsException()
    {
        Ex07_DiscountCalculator classUnderTest = createCalculator();
        
        classUnderTest.calcDiscount(-13);
    }

    // =>

    @Test
    public void testThatNegativeValueReturnsException_Junit5()
    {
        Ex07_DiscountCalculator classUnderTest = createCalculator();

        assertThrows(IllegalArgumentException.class, () -> classUnderTest.calcDiscount(-13));
    }

    // -----------------------------------

    private Ex07_DiscountCalculator createCalculator()
    {
        return new Ex07_DiscountCalculator();
    }
}
