package solutions;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Random;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex06_Dice;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ Ex06_Dice.class })
public class Ex06_DiceTest
{
    @Test
    public void shouldAddUpDiceRollsCorrectly()
    {
        PowerMockito.mockStatic(Math.class);
        PowerMockito.when(Math.random()).thenReturn(0.2, 0.4, 0.6, 0.8, 1.0);

        Ex06_Dice die = new Ex06_Dice();

        assertEquals(14, die.sumOfNumDiceRolls(4));
        assertEquals(70, die.sumOfNumDiceRolls(10));
    }

    @Test
    public void shouldAddUpDiceRollsCorrectly_V2() throws Exception
    {
        Random mockedRandom = Mockito.mock(Random.class);
        Mockito.when(mockedRandom.nextInt()).thenReturn(1, 2, 3, 4, 5, 6, 1, 6, 6, 2);
        PowerMockito.whenNew(Random.class).withNoArguments().thenReturn(mockedRandom);

        Ex06_Dice dice = new Ex06_Dice();

        assertAll(() -> assertEquals(36, dice.roll10()), 
                  () -> assertEquals(20, dice.roll10()));
    }
}