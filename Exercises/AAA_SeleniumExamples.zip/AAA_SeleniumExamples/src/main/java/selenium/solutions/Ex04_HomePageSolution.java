package selenium.solutions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex04_HomePageSolution
{
    private WebDriver    driver;

    private final String URL        = "http://www.vpl.ca";

    private final By     SEARCH_BOX = By.id("edit-search");
    private final By     SEARCH_BTN = By.id("edit-submit");

    public Ex04_HomePageSolution(WebDriver driver)
    {
        this.driver = driver;
    }

    public void open()
    {
        driver.get(URL);
    }

    public boolean isOpen()
    {
        return driver.getCurrentUrl().contains(URL);
    }

    public void searchFor(String keyword)
    {
        WebElement searchBox = driver.findElement(SEARCH_BOX);
        searchBox.clear();
        searchBox.sendKeys(keyword);

        WebElement searchBtn = driver.findElement(SEARCH_BTN);
        searchBtn.click();
    }
}
