package exercises.part7_8;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalTime;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_GreetingCreatorTest
{
    @Test
    public void testAfternoon()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(15, 0, 0));
        
        assertEquals("Good Afternoon", greeting);
    }

    @Test
    public void testMorning()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(11, 0, 0));
        
        assertEquals("Good Morning", greeting);
    }

    @Test
    public void testEvening()
    {
        String greeting = new Ex05_GreetingCreator().createGreeting(LocalTime.of(20, 0, 0));
        
        assertEquals("Good Evening", greeting);
    }    
}
