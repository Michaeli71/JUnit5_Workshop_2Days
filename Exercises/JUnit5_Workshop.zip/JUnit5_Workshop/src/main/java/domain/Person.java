package domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Person
{
    // just for the example
    public final String    name;

    public final LocalDate dateOfBirth;

    public final String    homeTown;

    public Person(String name, LocalDate dateOfBirth, String homeTown)
    {
        // Leerdammer
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.homeTown = homeTown;
    }

    public String getName()
    {
        return name;
    }

    public LocalDate getDateOfBirth()
    {
        return dateOfBirth;
    }

    public String getHomeTown()
    {
        return homeTown;
    }

    @Override
    public String toString()
    {
        return "Person [name=" + name + ", dateOfBirth=" + dateOfBirth + ", homeTown=" + homeTown + "]";
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(dateOfBirth, homeTown, name);
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        
        Person other = (Person) obj;
        return Objects.equals(dateOfBirth, other.dateOfBirth) && Objects.equals(homeTown, other.homeTown)
               && Objects.equals(name, other.name);
    }
}