package x_slides.part3_junit5_advanced;

import org.junit.jupiter.api.extension.AfterTestExecutionCallback;
import org.junit.jupiter.api.extension.BeforeTestExecutionCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class D_BenchmarkExtension implements BeforeTestExecutionCallback, 
                                             AfterTestExecutionCallback
{
    private long start;

    @Override
    public void beforeTestExecution(ExtensionContext ctx) throws Exception
    {
        start = System.currentTimeMillis();
    }

    @Override
    public void afterTestExecution(ExtensionContext ctx) throws Exception
    {
        System.err.println("Test " + ctx.getDisplayName() + " took " + 
                           (System.currentTimeMillis() - start) + " ms");        
    }
}