package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import utils.PrimeNumberChecker;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class X_DynamicTests
{
    @TestFactory // Iterator or Iterable also possible
    Collection<DynamicTest> dynamicTestsWithCollection()
    {
        DynamicTest addTest = DynamicTest.dynamicTest("Add test", () -> {
            int addExact = Math.addExact(1, 1);
            assertEquals(2, addExact);
        });
        DynamicTest multTest = DynamicTest.dynamicTest("Multiply Test", () -> {
            int multiplyExact = Math.multiplyExact(2, 2);
            assertEquals(4, multiplyExact);
        });

        return Arrays.asList(addTest, multTest);
    }

    // Wenn man grössere Wertebereiche abdecken möchte, 
    // dann ist ein Pramatrized Test eher ungünstig
    @TestFactory
    Stream<DynamicTest> dynamicTestsFromIntStream()
    {
        return IntStream.iterate(0, n -> n + 2).limit(100).mapToObj(n -> DynamicTest.dynamicTest("test" + n, () -> {
            boolean isEven = n % 2 == 0;
            assertTrue(isEven);
        }));
    }

    // Als eine Art Parametrized Test
    // Primechecker
    @TestFactory
    Stream<DynamicTest> dynamicTestsForPrimes()
    {
        // sample input and output
        List<Integer> inputList = Arrays.asList(2, 3, 6, 11, 13, 14);
        List<Boolean> expectedList = Arrays.asList(true, true, false, true, true, false);

        List<DynamicTest> dynTests = new ArrayList<>();
        for (int i = 0; i < inputList.size(); i++)
        {
            int value = inputList.get(i);
            boolean expected = expectedList.get(i);

            DynamicTest dynTest = DynamicTest.dynamicTest("Prime Test " + value + " => " + expected, () -> {
                boolean isPrime = PrimeNumberChecker.isPrime(value);
                assertEquals(expected, isPrime);
            });

            dynTests.add(dynTest);
        }
        return dynTests.stream();
    }
}
