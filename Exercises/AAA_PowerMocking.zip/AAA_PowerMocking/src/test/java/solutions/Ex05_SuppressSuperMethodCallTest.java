package solutions;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.api.support.membermodification.MemberModifier.suppress;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import exercises.Ex05_SubClass;
import exercises.Ex05_SuperClass;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ Ex05_SuperClass.class })
public class Ex05_SuppressSuperMethodCallTest
{
    @Test
    public void testSuppressSuperMethodCall() throws Exception
    {
        suppress(method(Ex05_SuperClass.class, "someMethod"));
        
        String result = new Ex05_SubClass().someMethod();
        
        assertEquals("RESULT FROM CHILD", result);
    }
}