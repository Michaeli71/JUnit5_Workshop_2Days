package exercises.part3;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex11_OptionalTest
{
    @Nested
    @DisplayName("Testfälle für ein leeres Optional")
    class EmptyOptionalTest
    {
        private Optional<String> emptyOptional;

        // TDOD
    }

    @Nested
    @DisplayName("Testfälle für ein vorhandenes Optional")
    class PresentOptionalTest
    {
        private static final String JUGS = "JUGS";

        private Optional<String> presentOptional;

        // TDOD
    }
}