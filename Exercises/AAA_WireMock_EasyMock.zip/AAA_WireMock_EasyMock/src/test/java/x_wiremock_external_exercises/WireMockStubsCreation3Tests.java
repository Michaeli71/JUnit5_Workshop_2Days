package x_wiremock_external_exercises;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.greaterThan;

import org.apache.http.client.ClientProtocolException;
import org.junit.Rule;
import org.junit.Test;

import com.github.tomakehurst.wiremock.junit.WireMockRule;

//https://www.ontestautomation.com/open-sourcing-my-workshop-on-wiremock/
public class WireMockStubsCreation3Tests {
	
	WireMockStubsCreation3  wma = new WireMockStubsCreation3 ();
	
	@Rule
	public WireMockRule wireMockRule = new WireMockRule(9876);
	
	@Test
	public void testExercise301() {
        
	    wma.setupStub9();
	         
	    given().
	    when().
	        get("http://localhost:9876/exercise301").
	    then().
	    	assertThat().
	    	statusCode(503).
	    and().
	    	statusLine(containsString("Service unavailable"));	    	
	}
	
	@Test
	public void testExercise302() {
        
	    wma.setupStub10();
	         
	    given().
	    when().
	        get("http://localhost:9876/exercise302").
	    then().
	        assertThat().
	        time(greaterThan(2000L));
	}
	
	@Test(expected = ClientProtocolException.class)
	public void testExercise303() {
        
	    wma.setupStub11();
	         
	    given().
	    when().
	        get("http://localhost:9876/exercise303").
	    then();
	}
}