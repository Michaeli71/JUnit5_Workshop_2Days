package exercises;

import java.util.Random;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex06_Dice
{    
    public int roll10()
    {
        int sum = 0;
        for (int i = 0; i < 10; i++)
        {
            int roll = new Random().nextInt();
            sum += roll;
        }
        return sum;
    }
    
    public int sumOfNumDiceRolls(int num)
    {
        int sum = 0;
        for (int i = 0; i < num; i++)
        {
            int roll = (int) (6 * Math.random()) + 1;
            sum += roll;
        }
        return sum;
    }
}
