package exercises;

class Factory {

	public static String factorObject() throws Exception {
		String s = "Hello HOCHSCHULSTART";
		checkString(s);
		return s;
	}

	private static void checkString(String s) throws Exception {
		throw new Exception();
	}
}