package x_slides.part5_6_dependencies_testability;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class ItemServiceTest
{
    @Mock
    private ItemRepository itemRepository;

    @InjectMocks
    private ItemService    itemService;

    @BeforeEach
    public void setUp() throws Exception
    {
        MockitoAnnotations.initMocks(this);
        
        System.out.println(itemRepository.getClass());
        System.out.println(itemService.getClass());
    }

    @Test
    public void testFindById()
    {
        // Given
        final Item mockedItem = new Item(42L, "Item 1", "Description 1", 100);
        Mockito.when(itemRepository.findById(42L)).thenReturn(mockedItem);
        
        // When
        final Item result = itemService.getItemById(42L);

        // Then
        Mockito.verify(itemRepository, Mockito.times(1)).findById(42L);
        assertEquals("Item 1", result.name);
    }
}