package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class E_FloatinPointTest
{
    @Test
    @DisplayName("\uD835\uDED1 = 3.1415 (with four digit precision)")
    void floatingArithemticRoundingForPI()
    {

        double value = calculatePI();
        double precision = 0.0001;

        assertEquals(3.1415, value, precision);
    }

    private double calculatePI()
    {
        return Math.PI;
    }
}
