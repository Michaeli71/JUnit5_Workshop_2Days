package exercises.part5_6.cheatsheet;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atMost;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoVerifyExample3
{
    @Test
    public void testGreetingCalls()
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        when(greeting.greet(anyString())).thenReturn("Hello Mockito1", "Hello Mockito2");
        
        // Act
        final Application app = new Application(greeting);
        final String result1 = app.generateMsg("Tim");
        final String result2 = app.generateMsg("Tom");
        final String result3 = app.generateMsg("Tim");
        
        // Assert
        verify(greeting, atLeast(1)).greet("Tim");
        verify(greeting, atMost(2)).greet("Tim");
        verify(greeting, times(3)).greet(anyString());
    }
}
