package mockserver_intro;

import static io.restassured.RestAssured.when;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockserver.client.MockServerClient;
import org.mockserver.junit.jupiter.MockServerExtension;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@ExtendWith(MockServerExtension.class)
public class MockServerIntroTest {
	
	MockServerClient client = new MockServerClient("127.0.0.1", 1080);
	
	public void setupStub() 
	{	
		client.when(
		        request()
		            .withMethod("GET")
		            .withPath("/an/endpoint")		            
		    )
		    .respond(
		        response()
		            .withStatusCode(200)
		            .withBody("You've reached a valid MockServer endpoint"));
	}

	@Test
	public void testStatusCodePositive() {

		setupStub();

		when().get("http://localhost:8090/an/endpoint").then().assertThat().statusCode(200);
	}
}
