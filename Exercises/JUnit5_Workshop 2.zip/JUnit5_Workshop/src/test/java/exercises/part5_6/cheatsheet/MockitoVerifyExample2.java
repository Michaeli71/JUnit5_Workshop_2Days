package exercises.part5_6.cheatsheet;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoVerifyExample2
{
    @Test
    public void testGreetingCalls()
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        when(greeting.greet(anyString())).thenReturn("Hello Mockito1", "Hello Mockito2");
        
        // Act
        final Application app = new Application(greeting);
        final String result1 = app.generateMsg("One");
        final String result2 = app.generateMsg("Two");
        final String result3 = app.generateMsg("Three");
        
        // Assert
        verify(greeting).greet("One");
        verify(greeting).greet("Two");
        verify(greeting).greet(anyString());
    }
}
