package exercises.part2;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex04_TestInfoExampleTest 
{
    @Test
    @Tag("Fast")
    @Tag("Cool")
    @DisplayName("5 + (-5) => 0 🤔")
    void mytestmethod(TestInfo ti)
    {
       // TODO
    }
}