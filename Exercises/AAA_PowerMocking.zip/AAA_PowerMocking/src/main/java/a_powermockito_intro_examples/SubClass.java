package a_powermockito_intro_examples;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class SubClass extends SuperClass
{    
    public String someMethod()
    {
        return "RESULT FROM CHILD";
    }
}