package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import utils.SundayCalculator;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_ParameterizedSundayCalculatorTest
{

    @Test
    void sundaysBetween()
    {
        final LocalDate start = LocalDate.of(2020, 1, 1);
        final LocalDate end = LocalDate.of(2020, 3, 3);

        final List<LocalDate> sundays = SundayCalculator.allSundaysBetween(start, end);

        final List<LocalDate> expectedSundays = Arrays
                        .asList(LocalDate.parse("2020-01-05"), LocalDate.parse("2020-01-12"),
                                LocalDate.parse("2020-01-19"), LocalDate.parse("2020-01-26"),
                                LocalDate.parse("2020-02-02"), LocalDate.parse("2020-02-09"),
                                LocalDate.parse("2020-02-16"), LocalDate.parse("2020-02-23"),
                                LocalDate.parse("2020-03-01"));

        assertEquals(expectedSundays, sundays);
    }

    // Schritt 1: Logik vereinfachen, um weitere Extraktion vorzubereiten 

    @Test
    void sundaysBetweenImproved()
    {
        final LocalDate start = LocalDate.of(2020, 1, 1);
        final LocalDate end = LocalDate.of(2020, 3, 3);

        final List<LocalDate> sundays = SundayCalculator.allSundaysBetween(start, end);

        final List<LocalDate> expectedSundays = Stream
                        .of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26", "2020-02-02", "2020-02-09",
                            "2020-02-16", "2020-02-23", "2020-03-01")
                        .map(day -> LocalDate.parse(day)).collect(Collectors.toList());

        assertEquals(expectedSundays, sundays);
    }

    // Schritt 2: Konvertierung in LocalDate in Methode auslagern

    @Test
    void sundaysBetweenImproved_V2()
    {
        final LocalDate start = LocalDate.of(2020, 1, 1);
        final LocalDate end = LocalDate.of(2020, 3, 3);

        final List<LocalDate> sundays = SundayCalculator.allSundaysBetween(start, end);

        final List<String> expectedSundaysAsStrings = List.of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26",
                                                              "2020-02-02", "2020-02-09", "2020-02-16", "2020-02-23",
                                                              "2020-03-01");
        final List<LocalDate> expectedSundays = convertToLocalDates(expectedSundaysAsStrings);

        assertEquals(expectedSundays, sundays);
    }

    private List<LocalDate> convertToLocalDates(final List<String> datesAsStings)
    {
        return datesAsStings.stream().map(day -> LocalDate.parse(day)).collect(Collectors.toList());
    }

    //Schritt 3: Bereitstellung Expected in Methode auslagern

    @Test
    void sundaysBetweenImproved_V3()
    {
        final LocalDate start = LocalDate.of(2020, 1, 1);
        final LocalDate end = LocalDate.of(2020, 3, 3);

        final List<LocalDate> sundays = SundayCalculator.allSundaysBetween(start, end);

        final List<String> expectedSundaysAsStrings = allExpectedDates();
        final List<LocalDate> expectedSundays = convertToLocalDates(expectedSundaysAsStrings);

        assertEquals(expectedSundays, sundays);
    }

    private List<String> allExpectedDates()
    {
        return List.of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26", "2020-02-02", "2020-02-09", "2020-02-16",
                       "2020-02-23", "2020-03-01");
    }

    // Schritt 4: Datumsbereich als Parameter aufnehmen

    @Test
    void sundaysBetweenImproved_V4()
    {
        final LocalDate start = LocalDate.of(2020, 1, 1);
        final LocalDate end = LocalDate.of(2020, 3, 3);

        final List<LocalDate> result = SundayCalculator.allSundaysBetween(start, end);

        final List<String> expectedSundaysAsStrings = allExpectedDatesForDateRange(start, end);
        final List<LocalDate> expected = convertToLocalDates(expectedSundaysAsStrings);

        assertEquals(expected, result);
    }

    private List<String> allExpectedDatesForDateRange(final LocalDate start, final LocalDate end)
    {
        return List.of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26", "2020-02-02", "2020-02-09", "2020-02-16",
                       "2020-02-23", "2020-03-01");
    }

    // Schritt 5: Umwandlung in Parameterized Test 

    @ParameterizedTest(name = "sundays between {0} and {1} => {2}")
    @MethodSource("startAndEndDateAndResults_V5")
    void sundaysBetweenImproved_V5(LocalDate start, LocalDate end, List<String> expectedAsStream)
    {
        final List<LocalDate> result = SundayCalculator.allSundaysBetween(start, end);

        final List<LocalDate> expected = convertToLocalDates(expectedAsStream);

        assertEquals(expected, result);
    }

    private static Stream<Arguments> startAndEndDateAndResults_V5()
    {
        return Stream.of(Arguments.of(LocalDate.of(2020, 1, 1), LocalDate.of(2020, 3, 3),
                                      List.of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26", "2020-02-02",
                                              "2020-02-09", "2020-02-16", "2020-02-23", "2020-03-01")));
    }

// Schritt 6: Weitere Test-Parametrierungen ergänzen

@ParameterizedTest(name = "sundays between {0} and {1} => {2}")
@MethodSource("startAndEndDateAndResults")
void sundaysBetweenImproved(LocalDate start, LocalDate end, List<String> expectedAsStream)
{
    final List<LocalDate> result = SundayCalculator.allSundaysBetween(start, end);

    final List<LocalDate> expected = convertToLocalDates(expectedAsStream);

    assertEquals(expected, result);
}

private static Stream<Arguments> startAndEndDateAndResults()
{
    return Stream.of(Arguments.of(LocalDate.of(2020, 1, 1), LocalDate.of(2020, 3, 3),
                                  List.of("2020-01-05", "2020-01-12", "2020-01-19", "2020-01-26", "2020-02-02",
                                          "2020-02-09", "2020-02-16", "2020-02-23", "2020-03-01")),
                     Arguments.of(LocalDate.of(1971, 2, 1), LocalDate.of(1971, 3, 1),
                                  List.of("1971-02-07", "1971-02-14", "1971-02-21", "1971-02-28")),
                     Arguments.of(LocalDate.of(2020, 4, 1), LocalDate.of(2020, 5, 1),
                                  List.of("2020-04-05", "2020-04-12", "2020-04-19", "2020-04-26")));
}
}