package intro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class LinksAndDropDownExample
{
    public static void main(String[] args) throws InterruptedException
    {
        System.setProperty("webdriver.gecko.driver", "/opt/WebDriver/bin/geckodriver");
        
        WebDriver driver = new FirefoxDriver();
        try {
            driver.get("file:///Users/michaeli/Desktop/LinksAndDropDownExample.html");
            driver.manage().window().maximize();
            
            driver.findElement(By.linkText("Heise")).click();
            driver.navigate().back();
            Thread.sleep(2000);

            Select selectByValue = new Select(driver.findElement(By.id("colors")));
            selectByValue.selectByValue("green");
            Thread.sleep(2000);

            Select selectByVisibleText = new Select(driver.findElement(By.id("fruits")));
            selectByVisibleText.selectByVisibleText("Lime");
            Thread.sleep(2000);
            
        } finally {
            driver.quit();
        } 
    }
}