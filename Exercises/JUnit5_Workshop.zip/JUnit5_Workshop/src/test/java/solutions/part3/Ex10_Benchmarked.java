package solutions.part3;

import org.junit.jupiter.api.extension.ExtendWith;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@ExtendWith(Ex06_BenchmarkExtension.class)
@interface Ex10_Benchmarked 
{
}
