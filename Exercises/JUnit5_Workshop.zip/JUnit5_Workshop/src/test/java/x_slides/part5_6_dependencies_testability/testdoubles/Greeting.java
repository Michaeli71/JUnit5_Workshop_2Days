package x_slides.part5_6_dependencies_testability.testdoubles;

public class Greeting 
{
	public String greet() 
	{
		return "Hello world!";
	}
}