package a_powermockito_intro_examples;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.support.membermodification.MemberMatcher.constructor;
import static org.powermock.api.support.membermodification.MemberModifier.suppress;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SuperClass.class, SubClass.class })
public class SuppressSuperConstructorCallTest
{
    @Test
    public void testSuppressSuperConstructorCall() 
    {
        suppress(constructor(SuperClass.class));
        
        String result = new SubClass().someMethod();
        
        assertEquals("RESULT FROM CHILD", result);
    }
}