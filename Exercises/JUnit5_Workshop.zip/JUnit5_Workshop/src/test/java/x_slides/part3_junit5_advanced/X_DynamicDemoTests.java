package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import utils.MathUtils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class X_DynamicDemoTests
{
    @TestFactory
    Stream<DynamicTest> dynamicTestsFromIntStream()
    {
        return IntStream.iterate(0, n -> n + 2).limit(10)
                        .mapToObj(n -> dynamicTest("test" + n, () -> assertTrue(n % 2 == 0)));
    }

    @TestFactory
    Collection<DynamicTest> dynamicTestsWithCollection()
    {
        return Arrays.asList(dynamicTest("Add test", () -> assertEquals(2, Math.addExact(1, 1))),
                             dynamicTest("Multiply Test", () -> assertEquals(4, Math.multiplyExact(2, 2))));
    }

    @TestFactory
    @DisplayName("check if all Fibonaccis are odd")
    Stream<DynamicTest> allFibonaccisAreOdd()
    {
        return IntStream.range(1, 13).map(MathUtils::fib)
                        .mapToObj(number -> dynamicTest("Fibonacci = " + number,
                                                        () -> assertTrue(MathUtils.isOdd(number))));
    }
}