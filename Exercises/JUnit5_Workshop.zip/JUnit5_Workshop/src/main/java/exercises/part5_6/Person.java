package exercises.part5_6;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Person
{
    int    id;
    String firstname;
    String lastname;
    int    age;

    public Person(int id, String firstname, String lastname, int age)
    {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
    }

    // GETTER + SETTER + toString() usw.
}
