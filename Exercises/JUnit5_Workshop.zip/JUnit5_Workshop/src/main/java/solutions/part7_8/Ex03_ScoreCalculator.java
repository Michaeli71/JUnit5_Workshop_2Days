package solutions.part7_8;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex03_ScoreCalculator 
{
    // Util-Klasse sollte keinen Default-Ctor haben!
    // Sonst auch keine 100% Testabdeckung
    private Ex03_ScoreCalculator()
    {
    }
    
	public static String calcScore(int score)
	{
		if (score < 45)
			return "fail";
		else 
		{
			if (score > 95)
				return "pass with distinction";
			
			return "pass";
		}
	}	
}
