#Windows 10 – CURL Protocol "'https" not supported or disabled in libcurl Error. ... 
#It's nothing to do with unsupported protocol but rather with wrong command line formatting. 
#In the windows version of CURL, you need to enclose the command with double quotes, instead of single quotes
curl -X POST --data '@unauthorized_invoices.json' "http://localhost:8080/__admin/mappings/new"
curl -X POST --data '@authorize.json' "http://localhost:8080/__admin/mappings/new"
curl -X POST --data '@authorized_invoices.json' "http://localhost:8080/__admin/mappings/new"

