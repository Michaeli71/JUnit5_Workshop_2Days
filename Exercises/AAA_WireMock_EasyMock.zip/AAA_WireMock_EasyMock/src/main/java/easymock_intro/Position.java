package easymock_intro;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public enum Position {
	CTO, TEAM_LEAD, LEAD_DEVELOPER, ARCHITECT, PROGRAMMER
}