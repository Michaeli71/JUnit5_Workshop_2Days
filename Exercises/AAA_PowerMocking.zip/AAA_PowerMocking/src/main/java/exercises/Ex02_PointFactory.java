package exercises;

import java.awt.Point;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex02_PointFactory
{
    public Point create()
    {
        // complex logic
        return new Point(11, 11);
    }
}
