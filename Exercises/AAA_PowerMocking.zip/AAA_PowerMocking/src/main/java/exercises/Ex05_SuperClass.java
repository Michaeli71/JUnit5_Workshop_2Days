package exercises;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Ex05_SuperClass
{
    public String someMethod()
    {
        throw new IllegalArgumentException();
    }
}