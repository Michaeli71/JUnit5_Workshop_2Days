package exercises.part5_6;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
//Korigere diesen Test
public class Ex02_PizzaServiceTest
{
    @Test
    public void orderPizza_should_send_sms()
    {
        // Arrange
        final Ex02_PizzaService service = new Ex02_PizzaService();

        // Act
        service.orderPizza("Diavolo");
        service.orderPizza("Surprise");

        // Assert ???
    }
}
