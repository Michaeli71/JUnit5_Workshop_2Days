package exercises;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
@RunWith(PowerMockRunner.class)
// TODO
public class Ex05_SuppressSuperMethodCallTest
{
    @Test
    public void testSuppressSuperMethodCall() throws Exception
    {
        // TODO
        
        String result = new Ex05_SubClass().someMethod();
        
        assertEquals("RESULT FROM CHILD", result);
    }
}